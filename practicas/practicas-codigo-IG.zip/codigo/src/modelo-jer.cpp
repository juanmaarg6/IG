// Nombre: Juan Manuel, Apellidos: Rodríguez Gómez, Titulación: GIM
// Email: juanmaarg6@correo.ugr.es, DNI: 49559494Z

#include "modelo-jer.h"

// ****************************************************************************
// Clases derivadas de MallaInd
// ****************************************************************************

// --------------------------------------------------------------------
// Clase 'SemiPoligono'

SemiPoligono::SemiPoligono(unsigned n)
:  MallaInd( "SemiPoligono" )
{
    assert(n > 1);
   
    // Vértices
    vertices.push_back({0,0,0});
    for(unsigned int i = 0; i < n; ++i)  
        vertices.push_back( {float(cos(i*M_PI/(n-1))), float(sin(i*M_PI/(n-1))), 0} );

    // Triángulos
    for(unsigned int i = 0; i < n; ++i) 
        triangulos.push_back( {0, i, i+1} );
}

// --------------------------------------------------------------------
// Clase 'LemniscataXPositivo'

LemniscataXPositivo::LemniscataXPositivo(unsigned n)
:  MallaInd( "Lemniscata X Positivo" )
{
   assert(n > 1);
   
   // Vértices
    vertices.push_back({0,0,0});

    for(unsigned int i = 0; i <= n; ++i)    // Ecuaciones paramétricas de la lemniscata
        vertices.push_back( { float( sqrt(2)*cos(i*float(M_PI/(2*n))) ) / float( 1 + sin(i*float(M_PI/(2*n)))*sin(i*float(M_PI/(2*n))) ), 
                              float( sqrt(2)*cos(i*float(M_PI/(2*n)))*sin(i*float(M_PI/(2*n))) ) / float( 1 + sin(i*float(M_PI/(2*n)))*sin(i*float(M_PI/(2*n))) ), 
                              0} );    
    
    for(unsigned int i = 0; i <= n; ++i)    // Ecuaciones paramétricas de la lemniscata
        vertices.push_back( { float( sqrt(2)*cos(i*float(M_PI/(2*n))) ) / float( 1 + sin(i*float(M_PI/(2*n)))*sin(i*float(M_PI/(2*n))) ), 
                              -float( sqrt(2)*cos(i*float(M_PI/(2*n)))*sin(i*float(M_PI/(2*n))) ) / float( 1 + sin(i*float(M_PI/(2*n)))*sin(i*float(M_PI/(2*n))) ), 
                              0} );

    // Triángulos
    for(unsigned int i = 0; i <= 2*n; ++i)
        triangulos.push_back( {0, i, i+1} );

    // Coordenadas de Textura
    for(unsigned int i = 0; i < 2*(n+1); ++i)  
        cc_tt_ver.push_back({float( sqrt(2)*cos(i*float(M_PI/(2*(n+1)))) ) / float( 1 + sin(i*float(M_PI/(2*(n+1))))*sin(i*float(M_PI/(2*(n+1)))) ), 
                             float( sqrt(2)*cos(i*float(M_PI/(2*(n+1))))*sin(i*float(M_PI/(2*(n+1)))) ) / float( 1 + sin(i*float(M_PI/(2*(n+1))))*sin(i*float(M_PI/(2*(n+1)))) )
                            });

}

// --------------------------------------------------------------------
// Clase 'TrianguloEquilatero'

TrianguloEquilatero::TrianguloEquilatero()
:  MallaInd( "Triangulo Equilátero" )
{   
    // Vértices
    vertices.push_back( {-1,0,0} );         // 0
    vertices.push_back( {1,0,0} );          // 1
    vertices.push_back( {0,sqrt(2),0} );    // 2

    // Triángulo
    triangulos.push_back( {0, 1, 2} );
}

// ****************************************************************************
// Clases derivadas de NodoGrafoEscena
// ****************************************************************************

// --------------------------------------------------------------------
// Clase 'Ojos'

Ojos::Ojos() {

    // Identificadores
    int ident_ojo_dcho = 2;
    int ident_ojo_izq = 3;

    // Materiales y Texturas
    Material * material_ojos = new Material(0.85, 1.0, 0.0, 1.0);

    // Objetos
    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({1, 0, 0}); // Color Rojo 

    // Nodos
    NodoGrafoEscena * ojo_izq = new NodoGrafoEscena();  // Ojo Izquierdo
    ojo_izq->ponerNombre("Ojo Izquierdo Butterfree");
    ojo_izq->ponerIdentificador(ident_ojo_izq);
    ojo_izq->agregar(MAT_Traslacion({2,0,1.5}));
    ojo_izq->agregar(MAT_Rotacion(30,{0,0,1}));
    ojo_izq->agregar(MAT_Escalado(1,1.75,1));  
    ojo_izq->agregar(esfera);

    NodoGrafoEscena * brillo_ojo_izq = new NodoGrafoEscena();
    brillo_ojo_izq->agregar(MAT_Traslacion({0.8,0.3,0.9}));
    brillo_ojo_izq->agregar(MAT_Escalado(0.3,0.3,0.3));    
    brillo_ojo_izq->agregar(MAT_Rotacion(30,{0,0,1}));
    brillo_ojo_izq->agregar(MAT_Escalado(1,1.75,1));  
    brillo_ojo_izq->agregar(new Esfera(32,64));

    NodoGrafoEscena * ojo_dcho = new NodoGrafoEscena();     // Ojo Derecho
    ojo_dcho->ponerNombre("Ojo Derecho Butterfree");
    ojo_dcho->ponerIdentificador(ident_ojo_dcho);
    ojo_dcho->agregar(MAT_Traslacion({-2,0,1.5}));
    ojo_dcho->agregar(MAT_Rotacion(-30,{0,0,1}));
    ojo_dcho->agregar(MAT_Escalado(1,1.75,1)); 
    ojo_dcho->agregar(esfera);

    NodoGrafoEscena * brillo_ojo_dcho = new NodoGrafoEscena();
    brillo_ojo_dcho->agregar(MAT_Traslacion({-0.8,0.3,0.9}));
    brillo_ojo_dcho->agregar(MAT_Escalado(0.3,0.3,0.3));     
    brillo_ojo_dcho->agregar(MAT_Rotacion(-30,{0,0,1}));
    brillo_ojo_dcho->agregar(MAT_Escalado(1,1.75,1)); 
    brillo_ojo_dcho->agregar(new Esfera(32,64));

    agregar(material_ojos);
    agregar(brillo_ojo_izq);
    agregar(brillo_ojo_dcho);
    agregar(MAT_Escalado(0.5, 0.5, 0.5));
    agregar(ojo_izq);
    agregar(ojo_dcho);
}

// --------------------------------------------------------------------
// Clase 'BaseCabeza_Ojos'

BaseCabeza_Ojos::BaseCabeza_Ojos() {

    // Identificadores
    int ident_base_cabeza = 1;
    
    // Materiales y Texturas
    Textura * textura_base_cabeza = new TexturaXY("text_morado.jpg");
    Material * material_base_cabeza = new Material(textura_base_cabeza, 0.5, 0.9, 0.3, 50.0);

    // Objetos 
    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({0.3412, 0.1373, 0.3922}); // Color morado 

    // Nodos 
    NodoGrafoEscena * base_cabeza = new NodoGrafoEscena();
    base_cabeza->ponerNombre("Cabeza Butterfree");
    base_cabeza->ponerIdentificador(ident_base_cabeza);
    base_cabeza->agregar(material_base_cabeza);
    base_cabeza->agregar(MAT_Escalado(2,1.5,1));
    base_cabeza->agregar(esfera);

    NodoGrafoEscena * ojos = new NodoGrafoEscena();
    ojos->agregar(new Ojos());

    agregar(base_cabeza);
    agregar(ojos);
}

// --------------------------------------------------------------------
// Clase 'BaseBoca_Colmillos'

BaseBoca_Colmillos::BaseBoca_Colmillos() {

    // Objetos 
    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({0.6235, 0.8353, 0.8196}); // Color aguamarina 

    Cono * cono = new Cono(10,50);

    // Nodos 
    NodoGrafoEscena * base_boca = new NodoGrafoEscena();
    base_boca->agregar(MAT_Escalado(2,1.5,1));
    base_boca->agregar(esfera);

    NodoGrafoEscena * colmillo_izq = new NodoGrafoEscena(); 
    colmillo_izq->agregar(MAT_Traslacion({-1.5,-0.9,0.4}));
    colmillo_izq->agregar(MAT_Rotacion(-30,{0,0,1}));
    colmillo_izq->agregar(MAT_Rotacion(135,{1,0,0}));
    colmillo_izq->agregar(cono);

    NodoGrafoEscena * colmillo_dcho = new NodoGrafoEscena(); 
    colmillo_dcho->agregar(MAT_Traslacion({1.5,-0.9,0.4}));
    colmillo_dcho->agregar(MAT_Rotacion(30,{0,0,1}));
    colmillo_dcho->agregar(MAT_Rotacion(135,{1,0,0}));
    colmillo_dcho->agregar(cono);

    agregar(base_boca);
    agregar(MAT_Escalado(0.7,0.7,0.7)); 
    agregar(colmillo_izq);
    agregar(colmillo_dcho);
}

// --------------------------------------------------------------------
// Clase 'BaseCuerpo'

BaseCuerpo::BaseCuerpo() {

    // Objetos 
    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({0.3412, 0.1373, 0.3922}); // Color morado 

    // Nodos 
    agregar(MAT_Traslacion({0,1.5,0}));
    agregar(MAT_Escalado(1.5,1.5,1.5));
    agregar(MAT_Escalado(1,1.1,1));
    agregar(esfera);
}

// --------------------------------------------------------------------
// Clase 'PieIzq_PieDcho'

PieIzq_PieDcho::PieIzq_PieDcho() {

    // Objetos 
    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({0.6235, 0.8353, 0.8196}); // Color aguamarina 

    // Nodos 
    NodoGrafoEscena * pie_izq = new NodoGrafoEscena(); 
    pie_izq->agregar(MAT_Traslacion({-1.2,0,0}));
    pie_izq->agregar(esfera);

    NodoGrafoEscena * pie_dcho = new NodoGrafoEscena(); 
    pie_dcho->agregar(MAT_Traslacion({1.2,0,0}));
    pie_dcho->agregar(esfera);

    agregar(MAT_Escalado(0.5,0.5,0.5));     
    agregar(MAT_Rotacion(-30,{1,0,0}));
    agregar(MAT_Escalado(1,3,1)); 
    agregar(pie_izq);
    agregar(pie_dcho);
}

// --------------------------------------------------------------------
// Clase 'PartesAntenaDcha'

PartesAntenaDcha::PartesAntenaDcha() {

    // Objetos 
    Cilindro * cilindro = new Cilindro(10,50);
    cilindro->ponerColor({0, 0, 0}); // Color negro 

    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({0, 0, 0}); // Color negro 

    // Nodos
    NodoGrafoEscena * antena_dcha1 = new NodoGrafoEscena();  // Parte Baja de la Antena Derecha
    antena_dcha1->agregar(MAT_Escalado(0.2,4,0.2));
    antena_dcha1->agregar(cilindro);

    NodoGrafoEscena * antena_dcha2 = new NodoGrafoEscena();  // Parte Media de la Antena Derecha
    antena_dcha2->agregar(MAT_Rotacion(30,{0,1,0}));
    antena_dcha2->agregar(MAT_Traslacion({0,3.85,-0.05}));
    antena_dcha2->agregar(MAT_Rotacion(45,{1,0,0}));
    antena_dcha2->agregar(MAT_Escalado(0.2,2,0.2));
    antena_dcha2->agregar(cilindro);

    NodoGrafoEscena * antena_dcha3 = new NodoGrafoEscena();  // Punta de la Antena Derecha
    antena_dcha3->agregar(MAT_Rotacion(30,{0,1,0}));
    antena_dcha3->agregar(MAT_Traslacion({0,5.7,1.8}));
    antena_dcha3->agregar(MAT_Escalado(0.4,0.4,0.4));    
    antena_dcha3->agregar(MAT_Rotacion(45,{1,0,0}));
    antena_dcha3->agregar(MAT_Escalado(1,2.5,1)); 
    antena_dcha3->agregar(esfera);

    agregar(MAT_Escalado(0.5,0.5,0.5));   
    agregar(antena_dcha1);
    agregar(antena_dcha2);
    agregar(antena_dcha3); 
}

// --------------------------------------------------------------------
// Clase 'PartesAntenaIzq'

PartesAntenaIzq::PartesAntenaIzq() {

    // Objetos 
    Cilindro * cilindro = new Cilindro(10,50);
    cilindro->ponerColor({0, 0, 0}); // Color negro 

    Esfera * esfera = new Esfera(32,64);
    esfera->ponerColor({0, 0, 0}); // Color negro 

    // Nodos 
    NodoGrafoEscena * antena_izq1 = new NodoGrafoEscena();    // Parte Baja de la Antena Izquierda
    antena_izq1->agregar(MAT_Escalado(0.2,4,0.2));
    antena_izq1->agregar(cilindro);

    NodoGrafoEscena * antena_izq2 = new NodoGrafoEscena();    // Parte Media de la Antena Izquierda
    antena_izq2->agregar(MAT_Rotacion(-30,{0,1,0}));
    antena_izq2->agregar(MAT_Traslacion({0,3.85,-0.05}));
    antena_izq2->agregar(MAT_Rotacion(45,{1,0,0}));
    antena_izq2->agregar(MAT_Escalado(0.2,2,0.2));
    antena_izq2->agregar(cilindro);

    NodoGrafoEscena * antena_izq3 = new NodoGrafoEscena();    // Punta de la Antena Izquierda
    antena_izq3->agregar(MAT_Rotacion(-30,{0,1,0}));
    antena_izq3->agregar(MAT_Traslacion({0,5.7,1.8}));
    antena_izq3->agregar(MAT_Escalado(0.4,0.4,0.4));    
    antena_izq3->agregar(MAT_Rotacion(45,{1,0,0}));
    antena_izq3->agregar(MAT_Escalado(1,2.5,1));  
    antena_izq3->agregar(esfera);

    agregar(MAT_Escalado(0.5,0.5,0.5));   
    agregar(antena_izq1);
    agregar(antena_izq2);
    agregar(antena_izq3); 
}

// --------------------------------------------------------------------
// Clase 'Mano'

Mano::Mano() {

    // Identificadores
    int ident_mano = 6;

    // Materiales y Texturas
    Material * material_mano = new Material(1.0, 1.0, 1.0, 20.0);

    // Objetos 
    SemiPoligono * semicirculo = new SemiPoligono(100);
    semicirculo->ponerColor({0.6235, 0.8353, 0.8196}); // Color aguamarina 

    TrianguloEquilatero * triangulo = new TrianguloEquilatero();
    triangulo->ponerColor({0.6235, 0.8353, 0.8196}); // Color aguamarina 

    MallaTriangulo * triangulo_rec = new MallaTriangulo();
    triangulo_rec->ponerColor({0.6235, 0.8353, 0.8196}); // Color aguamarina 

    // Nodos 
    NodoGrafoEscena * palma_mano = new NodoGrafoEscena();
    palma_mano->agregar(semicirculo);

    NodoGrafoEscena * dedo1 = new NodoGrafoEscena();
    dedo1->agregar(MAT_Traslacion({-3.05,0,0}));
    dedo1->agregar(MAT_Rotacion(180,{1,0,0}));
    dedo1->agregar(triangulo_rec);

    NodoGrafoEscena * dedo2 = new NodoGrafoEscena();
    dedo2->agregar(MAT_Rotacion(180,{1,0,0}));
    dedo2->agregar(triangulo);

    NodoGrafoEscena * dedo3 = new NodoGrafoEscena();
    dedo3->agregar(MAT_Traslacion({3.05,0,0}));
    dedo3->agregar(MAT_Rotacion(180,{1,0,0}));
    dedo3->agregar(MAT_Rotacion(180,{0,1,0}));
    dedo3->agregar(triangulo_rec);

    ponerNombre("Mano Butterfree");
    ponerIdentificador(ident_mano);
    agregar(material_mano);
    agregar(palma_mano);
    agregar(MAT_Escalado(0.33,0.33,0.33));
    agregar(dedo1);
    agregar(dedo2);
    agregar(dedo3);
}

// --------------------------------------------------------------------
// Clase 'ParteDeAla'

ParteDeAla::ParteDeAla() {

    // Materiales y Texturas
    Material * material_base_alas = new Material(new Textura("text_alas.jpg"), 1.0, 1.0, 0.0, 1.0);

    // Objetos 
    LemniscataXPositivo * lemniscata = new LemniscataXPositivo(100);

    LemniscataXPositivo * lemniscata_negra = new LemniscataXPositivo(100);
    lemniscata_negra->ponerColor({0, 0, 0}); // Color negro 

    // Nodos
    NodoGrafoEscena * base_parte_de_ala = new NodoGrafoEscena();
    base_parte_de_ala->agregar(material_base_alas);
    base_parte_de_ala->agregar(MAT_Escalado(2,2,2));
    base_parte_de_ala->agregar(lemniscata);

    NodoGrafoEscena * color_delantero1 = new NodoGrafoEscena();   // Colores Negros de la Parte Delantera del Ala
    color_delantero1->agregar(MAT_Escalado(2,0.5,1));
    color_delantero1->agregar(MAT_Rotacion(30,{0,0,1}));
    color_delantero1->agregar(MAT_Traslacion({0,0,0.001}));
    color_delantero1->agregar(lemniscata_negra);

    NodoGrafoEscena * color_delantero2 = new NodoGrafoEscena();
    color_delantero2->agregar(MAT_Escalado(2,0.5,1));
    color_delantero2->agregar(MAT_Rotacion(-30,{0,0,1}));
    color_delantero2->agregar(MAT_Traslacion({0,0,0.001}));
    color_delantero2->agregar(lemniscata_negra);

    NodoGrafoEscena * color_trasero1 = new NodoGrafoEscena();   // Colores Negros de la Parte Trasera del Ala
    color_trasero1->agregar(MAT_Escalado(2,0.5,1));
    color_trasero1->agregar(MAT_Rotacion(30,{0,0,1}));
    color_trasero1->agregar(MAT_Traslacion({0,0,-0.001}));
    color_trasero1->agregar(lemniscata_negra);

    NodoGrafoEscena * color_trasero2 = new NodoGrafoEscena();
    color_trasero2->agregar(MAT_Escalado(2,0.5,1));
    color_trasero2->agregar(MAT_Rotacion(-30,{0,0,1}));
    color_trasero2->agregar(MAT_Traslacion({0,0,-0.001}));
    color_trasero2->agregar(lemniscata_negra);


    agregar(base_parte_de_ala);
    agregar(color_delantero1);
    agregar(color_delantero2);
    agregar(color_trasero1);
    agregar(color_trasero2);
}

// --------------------------------------------------------------------
// Clase 'AlaSupDcha_AlaSupIzq'

AlaSupDcha_AlaSupIzq::AlaSupDcha_AlaSupIzq() {

    // Nodos
    NodoGrafoEscena * ala_sup_dcha = new NodoGrafoEscena();
    ala_sup_dcha->agregar(MAT_Traslacion({0.5,0,-1.3}));
    ala_sup_dcha->agregar(MAT_Rotacion(20,{1,0,0}));
    ala_sup_dcha->agregar(MAT_Rotacion(45,{0,0,1}));
    ala_sup_dcha->agregar(MAT_Rotacion(45,{0,1,0})); 
    ala_sup_dcha->agregar(MAT_Escalado(3,3,3));
    ala_sup_dcha->agregar(new ParteDeAla());
    
    NodoGrafoEscena * ala_sup_izq = new NodoGrafoEscena();
    ala_sup_izq->agregar(MAT_Traslacion({-0.5,0,-1.3}));
    ala_sup_izq->agregar(MAT_Rotacion(20,{1,0,0}));
    ala_sup_izq->agregar(MAT_Rotacion(-45,{0,0,1}));
    ala_sup_izq->agregar(MAT_Rotacion(135,{0,1,0}));
    ala_sup_izq->agregar(MAT_Escalado(3,3,3));
    ala_sup_izq->agregar(new ParteDeAla());

    agregar(ala_sup_dcha);
    agregar(ala_sup_izq);
}

// --------------------------------------------------------------------
// Clase 'AlaInfDcha_AlaInfIzq'

AlaInfDcha_AlaInfIzq::AlaInfDcha_AlaInfIzq() {

    // Nodos
    NodoGrafoEscena * ala_inf_dcha = new NodoGrafoEscena();
    ala_inf_dcha->agregar(MAT_Traslacion({0.5,0,-1.3}));
    ala_inf_dcha->agregar(MAT_Rotacion(-5,{1,0,0}));
    ala_inf_dcha->agregar(MAT_Rotacion(-45,{0,0,1}));
    ala_inf_dcha->agregar(MAT_Rotacion(45,{0,1,0}));
    ala_inf_dcha->agregar(MAT_Escalado(1.5,1.5,1.5));
    ala_inf_dcha->agregar(new ParteDeAla());

    NodoGrafoEscena * ala_inf_izq = new NodoGrafoEscena();
    ala_inf_izq->agregar(MAT_Traslacion({-0.5,0,-1.3}));
    ala_inf_izq->agregar(MAT_Rotacion(-5,{1,0,0}));
    ala_inf_izq->agregar(MAT_Rotacion(45,{0,0,1}));
    ala_inf_izq->agregar(MAT_Rotacion(135,{0,1,0}));
    ala_inf_izq->agregar(MAT_Escalado(1.5,1.5,1.5));
    ala_inf_izq->agregar(new ParteDeAla());

    agregar(ala_inf_dcha);
    agregar(ala_inf_izq);
}

// --------------------------------------------------------------------
// Clase 'Butterfree'

Butterfree::Butterfree(){

    ponerNombre( std::string("Butterfree") );

    // Identificadores
    int ident_boca = 4;
    int ident_cuerpo = 5;
    int ident_pies = 7;
    int ident_alas_sup = 8;
    int ident_alas_inf = 9;
    int ident_antena_dcha = 10;
    int ident_antena_izq = 11;

    // Materiales y Texturas
    Material * material_boca = new Material(0.8, 0.0, 1.0, 20.0);

    Textura * textura_cuerpo = new TexturaXY("text_morado.jpg");
    Material * material_cuerpo = new Material(textura_cuerpo, 0.5, 0.9, 0.3, 20.0);

    Material * material_pies = new Material(0.8, 0.0, 1.0, 20.0);

    // Nodos 
    NodoGrafoEscena * cabeza = new NodoGrafoEscena();
    cabeza->agregar(MAT_Traslacion({0,4,0}));
    cabeza->agregar(new BaseCabeza_Ojos());

    NodoGrafoEscena * boca = new NodoGrafoEscena();
    boca->ponerNombre("Boca Butterfree");
    boca->ponerIdentificador(ident_boca);
    boca->agregar(material_boca);
    boca->agregar(MAT_Traslacion({0,3.8,1}));
    boca->agregar(MAT_Escalado(0.2,0.2,0.2));
    boca->agregar(new BaseBoca_Colmillos());

    NodoGrafoEscena * cuerpo = new NodoGrafoEscena();
    cuerpo->ponerNombre("Cuerpo Butterfree");
    cuerpo->ponerIdentificador(ident_cuerpo);
    cuerpo->agregar(material_cuerpo);
    cuerpo->agregar(new BaseCuerpo());

    NodoGrafoEscena * mano_izquierda = new NodoGrafoEscena();
    mano_izquierda->agregar(MAT_Traslacion({-0.8, 2, 1.3}));
    mano_izquierda->agregar(MAT_Rotacion(-33,{0,1,0}));
    mano_izquierda->agregar(MAT_Rotacion(90,{0,0,1}));
    mano_izquierda->agregar(MAT_Escalado(0.4,0.4,0.4));
    mano_izquierda->agregar(new Mano());

    NodoGrafoEscena * mano_derecha = new NodoGrafoEscena();
    mano_derecha->agregar(MAT_Traslacion({0.8, 2, 1.3}));
    mano_derecha->agregar(MAT_Rotacion(33,{0,1,0}));
    mano_derecha->agregar(MAT_Rotacion(-90,{0,0,1}));
    mano_derecha->agregar(MAT_Escalado(0.4,0.4,0.4));
    mano_derecha->agregar(new Mano());

    NodoGrafoEscena * pies = new NodoGrafoEscena();
    pies->ponerNombre("Pies Butterfree");
    pies->ponerIdentificador(ident_pies);
    pies->agregar(material_pies);
    pies->agregar(MAT_Traslacion({0,-1.2,0.6}));
    pies->agregar(new PieIzq_PieDcho());

    NodoGrafoEscena * alas_superiores = new NodoGrafoEscena();
    alas_superiores->ponerNombre("Alas Superiores Butterfree");
    alas_superiores->ponerIdentificador(ident_alas_sup);
    alas_superiores->agregar(MAT_Traslacion({0,2,0}));
    unsigned ind1 = alas_superiores->agregar(MAT_Rotacion(0,{1,0,0}));  // Animación: Rotación de las Alas Superiores respecto al eje X
    alas_superiores->agregar(new AlaSupDcha_AlaSupIzq());

    NodoGrafoEscena * alas_inferiores = new NodoGrafoEscena();
    alas_inferiores->ponerNombre("Alas Inferiores Butterfree");
    alas_inferiores->ponerIdentificador(ident_alas_inf);
    alas_inferiores->agregar(MAT_Traslacion({0,1,0}));
    unsigned ind2 = alas_inferiores->agregar(MAT_Rotacion(0,{1,0,0}));  // Animación: Rotación de las Alas Inferiores respecto al eje X
    alas_inferiores->agregar(new AlaInfDcha_AlaInfIzq());

    NodoGrafoEscena * antena_dcha = new NodoGrafoEscena();
    antena_dcha->ponerNombre("Antena Butterfree");
    antena_dcha->ponerIdentificador(ident_antena_dcha);
    antena_dcha->agregar(MAT_Traslacion({1,5,0}));
    unsigned ind3 = antena_dcha->agregar(MAT_Rotacion(0,{0,1,0}));  // Animación: Rotación de la Antena Derecha respecto al eje Y
    antena_dcha->agregar(new PartesAntenaDcha());

    NodoGrafoEscena * antena_izq = new NodoGrafoEscena();
    antena_izq->ponerNombre("Antena Butterfree");
    antena_izq->ponerIdentificador(ident_antena_izq);
    antena_izq->agregar(MAT_Traslacion({-1,5,0}));
    unsigned ind4 = antena_izq->agregar(MAT_Rotacion(0,{0,1,0}));  // Animación: Rotación de la Antena Izquierda respecto al eje Y
    antena_izq->agregar(new PartesAntenaIzq());
   
    unsigned ind5 = agregar(MAT_Traslacion({4,3,0}));  // Animación: Traslación a coordenadas aleatorias donde cada componente se encuentra entre ? y ?
    agregar(cabeza);
    agregar(boca);
    agregar(cuerpo);
    agregar(pies);
    agregar(antena_dcha);
    agregar(antena_izq);
    agregar(mano_izquierda);
    agregar(mano_derecha);
    agregar(alas_superiores);
    agregar(alas_inferiores);

    matriz_rot1 = alas_superiores->leerPtrMatriz(ind1);
    matriz_rot2 = alas_inferiores->leerPtrMatriz(ind2);
    matriz_rot3 = antena_dcha->leerPtrMatriz(ind3);
    matriz_rot4 = antena_izq->leerPtrMatriz(ind4);
    matriz_tras = leerPtrMatriz(ind5);
}

unsigned Butterfree::leerNumParametros() const {
   return NUM_PARAMS;
}

void Butterfree::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {   
    case 0:
        fijarAnguloGiroAlpha(angulo1*sin(5*t_sec));
        break;
    case 1:
        fijarAnguloGiroBeta(angulo2*sin(5*t_sec));
        break;
    case 2:
        fijarAnguloGiroGamma(angulo3*sin(2*t_sec));
        break;
    case 3:
        fijarAnguloGiroDelta(angulo4*sin(4*t_sec));
        break;
    case 4:
        fijarTraslacion(4*cos(velocidad_tras*t_sec), 
                        3*cos(velocidad_tras*t_sec)*cos(velocidad_tras*t_sec),
                        4*sin(velocidad_tras*t_sec));
    default:
        break;
   }
}

void Butterfree::fijarAnguloGiroAlpha(float alpha) {
    *matriz_rot1 = MAT_Rotacion(alpha, {1,0,0});
}

void Butterfree::fijarAnguloGiroBeta(float beta) {
    *matriz_rot2 = MAT_Rotacion(beta, {1,0,0});
}

void Butterfree::fijarAnguloGiroGamma(float gamma) {
    *matriz_rot3 = MAT_Rotacion(gamma, {0,1,0});
}

void Butterfree::fijarAnguloGiroDelta(float delta) {
    *matriz_rot4 = MAT_Rotacion(delta, {0,1,0});
}

void Butterfree::fijarTraslacion(float x, float y, float z) {
    *matriz_tras = MAT_Traslacion({x,y,z});
}