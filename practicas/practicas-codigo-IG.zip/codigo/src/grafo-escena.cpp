// Nombre: Juan Manuel, Apellidos: Rodríguez Gómez, Titulación: GIM
// Email: juanmaarg6@correo.ugr.es, DNI: 49559494Z

// *********************************************************************
// **
// ** Gestión de una grafo de escena (implementación)
// ** Copyright (C) 2016 Carlos Ureña
// **
// ** This program is free software: you can redistribute it and/or modify
// ** it under the terms of the GNU General Public License as published by
// ** the Free Software Foundation, either version 3 of the License, or
// ** (at your option) any later version.
// **
// ** This program is distributed in the hope that it will be useful,
// ** but WITHOUT ANY WARRANTY; without even the implied warranty of
// ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ** GNU General Public License for more details.
// **
// ** You should have received a copy of the GNU General Public License
// ** along with this program.  If not, see <http://www.gnu.org/licenses/>.
// **
// *********************************************************************

#include "ig-aux.h"
#include "grafo-escena.h"

using namespace std ;

// *********************************************************************
// Entrada del nodo del Grafo de Escena

// ---------------------------------------------------------------------
// Constructor para entrada de tipo sub-objeto

EntradaNGE::EntradaNGE( Objeto3D * pObjeto )
{
   assert( pObjeto != NULL );
   tipo   = TipoEntNGE::objeto ;
   objeto = pObjeto ;
}
// ---------------------------------------------------------------------
// Constructor para entrada de tipo "matriz de transformación"

EntradaNGE::EntradaNGE( const Matriz4f & pMatriz )
{
   tipo    = TipoEntNGE::transformacion ;
   matriz  = new Matriz4f() ; // matriz en el heap, puntero propietario
   *matriz = pMatriz ;
}

// ---------------------------------------------------------------------
// Constructor para entrada de tipo "matriz de transformación"

EntradaNGE::EntradaNGE( Material * pMaterial )
{
   assert( pMaterial != NULL );
   tipo     = TipoEntNGE::material ;
   material = pMaterial ;
}

// -----------------------------------------------------------------------------
// Destructor de una entrada

EntradaNGE::~EntradaNGE()
{
   /**  no fnciona debido a que se hacen copias (duplicados) de punteros
   if ( tipo == TipoEntNGE::transformacion )
   {
      assert( matriz != NULL );
      delete matriz ;
      matriz = NULL ;
   }
   * **/
}

// *****************************************************************************
// Nodo del grafo de escena: contiene una lista de entradas
// *****************************************************************************

// -----------------------------------------------------------------------------
// Visualiza usando OpenGL

void NodoGrafoEscena::visualizarGL( ContextoVis & cv )
{
   // COMPLETAR: práctica 3: recorrer las entradas y visualizar cada nodo.
   // ........
   
   // Al inicio, registrar material activo
   Material * material_pre = cv.iluminacion ? cv.material_act : nullptr;
   
   tup_mat::Tupla4f color;
   color = leerFijarColVertsCauce(cv);

   // Guardar modelview actual
   cv.cauce->pushMM();
   
   // Recorrer todas las entradas del array que hay en el nodo
   for(unsigned i = 0; i < entradas.size(); ++i)
      switch(entradas[i].tipo)
      {
         case TipoEntNGE::objeto:                        // Entrada objeto
            entradas[i].objeto->visualizarGL(cv);        // Visualizar objeto
            break;

         case TipoEntNGE::transformacion:                // Entrada transformación
            cv.cauce->compMM( *(entradas[i].matriz) );   // Componer matriz
            break;

         case TipoEntNGE::material:                      // Entrada material
            if( cv.iluminacion )
               entradas[i].material->activar(cv);
            break;

         case TipoEntNGE::noInicializado:                // Entrada no inicializada
            break;
      }
   
   // Restaurar modelview guardada
   cv.cauce->popMM() ;
   
   // COMPLETAR: práctica 4: en la práctica 4, si 'cv.iluminacion' es 'true',
   // se deben de gestionar los materiales:
   //   1. guardar puntero al material activo al inicio (está en cv.material_act)
   //   2. si una entrada des de tipo material, activarlo y actualizar 'cv.material_act'
   //   3. al finalizar, restaurar el material activo al inicio (si es distinto del actual)
   cv.cauce->fijarColor(color);

   if ( material_pre != cv.material_act )
      if ( material_pre != nullptr )
         material_pre->activar( cv );
}




// *****************************************************************************
// visualizar pura y simplemente la geometría, sin colores, normales, coord. text. etc...

void NodoGrafoEscena::visualizarGeomGL( ContextoVis & cv )
{
   // comprobar que hay un cauce en 'cv' 
   assert( cv.cauce != nullptr );
  

   // COMPLETAR: práctica 3
   //
   // Este método hace un recorrido de las entradas del nodo, parecido a 'visualizarGL', teniendo 
   // en cuenta estos puntos:
   //
   // - usar push/pop de la matriz de modelado al inicio/fin (al igual que en visualizarGL)
   // - recorrer las entradas, llamando recursivamente a 'visualizarGeomGL' en los nodos u objetos hijos
   // - ignorar el color o identificador del nodo (se supone que el color ya está prefijado antes de la llamada)
   // - ignorar las entradas de tipo material, y la gestión de materiales (se usa sin iluminación)
   // ........

   // Guardar modelview actual
   cv.cauce->pushMM();
   
   // Recorrer todas las entradas del array que hay en el nodo
   for(unsigned i = 0; i < entradas.size(); ++i)
      switch(entradas[i].tipo)
      {
         case TipoEntNGE::objeto:                        // Entrada objeto
            entradas[i].objeto->visualizarGeomGL(cv);        // Visualizar objeto
            break;

         case TipoEntNGE::transformacion:                // Entrada transformación
            cv.cauce->compMM( *(entradas[i].matriz) );   // Componer matriz
            break;

         case TipoEntNGE::material:                      // Entrada material
            break;

         case TipoEntNGE::noInicializado:                // Entrada no inicializada
            break;
      }
   
   // Restaurar modelview guardada
   cv.cauce->popMM() ;

}

// -----------------------------------------------------------------------------

NodoGrafoEscena::NodoGrafoEscena()
{

}

// -----------------------------------------------------------------------------
// Añadir una entrada (al final).
// genérica (de cualqiuer tipo de entrada)

unsigned NodoGrafoEscena::agregar( const EntradaNGE & entrada )
{
   // COMPLETAR: práctica 3: agregar la entrada al nodo, devolver índice de la entrada agregada
   // ........
   entradas.push_back(entrada);

   return (entradas.size() - 1);

}
// -----------------------------------------------------------------------------
// construir una entrada y añadirla (al final)
// objeto (copia solo puntero)

unsigned NodoGrafoEscena::agregar( Objeto3D * pObjeto )
{
   return agregar( EntradaNGE( pObjeto ) );
}
// ---------------------------------------------------------------------
// construir una entrada y añadirla (al final)
// matriz (copia objeto)

unsigned NodoGrafoEscena::agregar( const Matriz4f & pMatriz )
{
   return agregar( EntradaNGE( pMatriz ) );
}
// ---------------------------------------------------------------------
// material (copia solo puntero)
unsigned NodoGrafoEscena::agregar( Material * pMaterial )
{
   return agregar( EntradaNGE( pMaterial ) );
}

// devuelve el puntero a la matriz en la i-ésima entrada
Matriz4f * NodoGrafoEscena::leerPtrMatriz( unsigned indice )
{
   // COMPLETAR: práctica 3: devolver puntero la matriz en ese índice
   //   (debe de dar error y abortar si no hay una matriz en esa entrada)
   // ........(sustituir 'return nullptr' por lo que corresponda)
   assert( indice < entradas.size() );
   assert( entradas[indice].tipo == TipoEntNGE::transformacion );
   assert( entradas[indice].matriz != nullptr );

   return entradas[indice].matriz ;


}
// -----------------------------------------------------------------------------
// si 'centro_calculado' es 'false', recalcula el centro usando los centros
// de los hijos (el punto medio de la caja englobante de los centros de hijos)

void NodoGrafoEscena::calcularCentroOC()
{

   // COMPLETAR: práctica 5: calcular y guardar el centro del nodo
   //    en coordenadas de objeto (hay que hacerlo recursivamente)
   //   (si el centro ya ha sido calculado, no volver a hacerlo)
   // ........
   if(centro_calculado) 
      return;

   int num_hijos = 0;
   Matriz4f mmodelado = MAT_Ident();
   Tupla3f centro_aux = {0,0,0};

   for(unsigned int i = 0; i < entradas.size(); i++) {
      if(entradas[i].tipo == TipoEntNGE::transformacion )
         mmodelado = mmodelado * (*entradas[i].matriz);
      if(entradas[i].tipo == TipoEntNGE::objeto ){
         entradas[i].objeto->calcularCentroOC();
         centro_aux = centro_aux + (mmodelado * entradas[i].objeto->leerCentroOC());
         num_hijos++;
      }
   }

   ponerCentroOC(centro_aux/float(num_hijos));
   centro_calculado = true;
}

// -----------------------------------------------------------------------------
// método para buscar un objeto con un identificador y devolver un puntero al mismo

bool NodoGrafoEscena::buscarObjeto
(
   const int         ident_busc, // identificador a buscar
   const Matriz4f &  mmodelado,  // matriz de modelado
   Objeto3D       ** objeto,     // (salida) puntero al puntero al objeto
   Tupla3f &         centro_wc   // (salida) centro del objeto en coordenadas del mundo
)
{
   assert( 0 < ident_busc );

   // COMPLETAR: práctica 5: buscar un sub-objeto con un identificador
   // Se deben de dar estos pasos:

   Matriz4f mmodelado_aux = mmodelado;

   // 1. calcula el centro del objeto, (solo la primera vez)
   // ........
   calcularCentroOC();

   // 2. si el identificador del nodo es el que se busca, ya está (terminar)
   // ........
   if(leerIdentificador() == ident_busc) {
      *objeto = this;
      centro_wc = mmodelado*leerCentroOC();
      return true;
   }

   // 3. El nodo no es el buscado: buscar recursivamente en los hijos
   //    (si alguna llamada para un sub-árbol lo encuentra, terminar y devolver 'true')
   // ........
   else {
      for(unsigned int i = 0; i < entradas.size(); i++) {
         if(entradas[i].tipo == TipoEntNGE::transformacion )
            mmodelado_aux = mmodelado_aux * (*entradas[i].matriz);
         if(entradas[i].tipo == TipoEntNGE::objeto)
            if(entradas[i].objeto->buscarObjeto(ident_busc, mmodelado_aux, objeto, centro_wc))
               return true;
      }
   }

   // ni este nodo ni ningún hijo es el buscado: terminar
   return false ;
}

// -----------------------------------------------------------------------------
// Clase 'GrafoEstrellaX

GrafoEstrellaX::GrafoEstrellaX(unsigned n) {

   ponerNombre( std::string("Grafo Estrella X") );
   assert(n > 1);

   // Animación: Giro de toda la figura respecto al eje Z
   unsigned ind1 = agregar(MAT_Rotacion(0,{0,0,1}));
   
   // Estrella
   NodoGrafoEscena * estrella = new NodoGrafoEscena();
   estrella->agregar(MAT_Escalado(1.3/0.5, 1.3/0.5, 1));
   estrella->agregar(MAT_Traslacion({-0.5, -0.5, 0}));
   estrella->agregar(new EstrellaZ(n));
   agregar(estrella); 

   // Conos
   NodoGrafoEscena * cono = new NodoGrafoEscena();
   cono->agregar(MAT_Traslacion({1.3,0,0}));
   cono->agregar(MAT_Rotacion(-90,{0,0,1}));
   cono->agregar(MAT_Escalado(0.14,0.15,0.14));
   cono->agregar(new Cono(10,10));

   float grado= 360.0/(n*1.0);

   for(unsigned i = 0; i < n; ++i) {
      agregar(MAT_Rotacion(grado,{0,0,1}));
      agregar(cono);
   }

   // Matriz de rotación para la animación
   matriz_rot = leerPtrMatriz(ind1);
}

unsigned GrafoEstrellaX::leerNumParametros() const {
   return NUM_PARAMS;
}

void GrafoEstrellaX::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {
      case 0:
         fijarAnguloGiro(angulo*t_sec);
         break;
      
      default:
         break;
   }
}

void GrafoEstrellaX::fijarAnguloGiro(const float alpha) {
   *matriz_rot = MAT_Rotacion(alpha,{0,0,1});
}

// -----------------------------------------------------------------------------
// Clase 'GrafoCubos

GrafoCubos::GrafoCubos() {

   ponerNombre( std::string("Grafo Cubos") );

   // Rejilla
   NodoGrafoEscena * rejilla= new NodoGrafoEscena();
   rejilla->agregar(MAT_Traslacion({-0.5,-0.5,-0.5}));
   rejilla->agregar(new RejillaY(dim_rejilla,dim_rejilla));

   // Cubo
   NodoGrafoEscena * cubo = new NodoGrafoEscena();
   unsigned ind1 = cubo->agregar(MAT_Rotacion(0,{0,1,0}));  // Animación: Cada cubo pequeño rota entorno al eje que pasa por su centro y el origen
   cubo->agregar(MAT_Traslacion({0,-0.75,0}));
   cubo->agregar(MAT_Escalado(0.15,0.25,0.15));
   cubo->agregar(new Cubo());

   // Agregamos 4 caras de nuestro objeto compuesto rotando cada objeto 90 grados sobre el eje X
   for(int i = 0; i < 4; i++){
      agregar(MAT_Rotacion(90,{1,0,0}));
      agregar(rejilla);
      agregar(cubo);
   }

   // Agregamos las 2 caras restantes de nuestro objeto compuesto rotando cada objeto 90 grados sobre el eje Z
   agregar(MAT_Rotacion(90,{0,0,1}));
   agregar(rejilla);
   agregar(cubo);
   agregar(MAT_Rotacion(180,{0,0,1}));
   agregar(rejilla);
   agregar(cubo);

   matriz_rot = cubo->leerPtrMatriz(ind1);
}

unsigned GrafoCubos::leerNumParametros() const {
   return NUM_PARAMS;
}

void GrafoCubos::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {
   case 0:
      fijarAnguloGiro(angulo*t_sec);
      break;
   
   default:
      break;
   }
}

void GrafoCubos::fijarAnguloGiro(float alpha) {
   *matriz_rot = MAT_Rotacion(alpha, {0,1,0});
}

// -----------------------------------------------------------------------------
// Clase 'GrafoToros

GrafoToros::GrafoToros() {

   ponerNombre( std::string("Grafo Toros") );

   // Objetos
   Toro * toro_rojo = new Toro(32, 64, 6.5, 0, 0.5);
   toro_rojo->ponerColor({1,0,0});

   Toro * toro_verde = new Toro(32, 64, 2.5, 0, 0.5);
   toro_verde->ponerColor({0,1,0});

   Toro * toro_azul = new Toro(32, 64, -2.5, 0, 0.5);
   toro_azul->ponerColor({0,0,1});

   // Nodos
   NodoGrafoEscena * toro_ext = new NodoGrafoEscena();    // Toro Exterior
   toro_ext->agregar(MAT_Rotacion(90, {1,0,0}));
   toro_ext->agregar(toro_rojo);

   NodoGrafoEscena * toro_int1 = new NodoGrafoEscena();   // Toro Interior 1
   unsigned ind1 = toro_int1->agregar(MAT_Rotacion(0,{1,0,0})); 
   toro_int1->agregar(MAT_Traslacion({3,0,0}));
   toro_int1->agregar(toro_verde);

   NodoGrafoEscena * toro_int2 = new NodoGrafoEscena();    // Toro Interior 2
   unsigned ind2 = toro_int2->agregar(MAT_Rotacion(0,{1,0,0})); 
   toro_int2->agregar(MAT_Traslacion({-3,0,0}));
   toro_int2->agregar(toro_azul);


   unsigned ind3 = agregar(MAT_Rotacion(0,{0,1,0}));
   agregar(toro_int2);
   agregar(toro_int1);
   agregar(toro_ext);

   matriz_rot1 = toro_int1->leerPtrMatriz(ind1);
   matriz_rot2 = toro_int2->leerPtrMatriz(ind2);
   matriz_rot3 = leerPtrMatriz(ind3);
}

unsigned GrafoToros::leerNumParametros() const {
   return NUM_PARAMS;
}

void GrafoToros::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {
   case 0:
      fijarAnguloGiro1(angulo1*t_sec);
      break;
   case 1:
      fijarAnguloGiro2(angulo2*t_sec);
      break;
   case 2:
      fijarAnguloGiro3(angulo3*t_sec);
      break;

   default:
      break;
   }
}

void GrafoToros::fijarAnguloGiro1(float alpha) {
   *matriz_rot1 = MAT_Rotacion(alpha, {1,0,0});
}

void GrafoToros::fijarAnguloGiro2(float beta) {
   *matriz_rot2 = MAT_Rotacion(beta, {1,0,0});
}
void GrafoToros::fijarAnguloGiro3(float gamma) {
   *matriz_rot3 = MAT_Rotacion(gamma, {0,1,0});
}

// -----------------------------------------------------------------------------
// Clase 'GrafoTunel

GrafoTunel::GrafoTunel() {

   ponerNombre( std::string("Grafo Tunel") );

   unsigned ind1 = agregar(MAT_Escalado(1,1,1));
   agregar(new Tunel());

   matriz_esc = leerPtrMatriz(ind1);
}

unsigned GrafoTunel::leerNumParametros() const {
   return NUM_PARAMS;
}

void GrafoTunel::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {
   case 0: {
      float x = Oscilacion(t_sec, 0, 2, velocidad_esc_x);
      fijarEscaladoX(x);
      break;
   }

   default:
      break;
   }
}

void GrafoTunel::fijarEscaladoX(float lambda) {
   *matriz_esc = MAT_Escalado(lambda,1,1);
}

float GrafoTunel::Oscilacion(const float t_sec, const float min, const float max, const float n) {
   const float a = (min+max)/2;
   const float b = (max-min)/2;
   return( a+b*sin(2*M_PI*n*t_sec) );
}

// -----------------------------------------------------------------------------
// Clase 'EsferaPatas

EsferaPatas::EsferaPatas(unsigned n) : NodoGrafoEscena(){
   assert(n>1);

   ponerNombre( std::string("EsferaPatas") );

   Esfera * esf = new Esfera(50,50);
   esf->ponerColor({1,0,0});

   Cilindro * cilindro = new Cilindro(50,50);
   cilindro->ponerColor({0,1,0});

   NodoGrafoEscena *esfera = new NodoGrafoEscena();
   esfera->agregar(MAT_Escalado(0.5,0.5,0.5));
   unsigned ind_esf = esfera->agregar(MAT_Traslacion({0.0,0.0,0.0}));
   esfera->agregar(esf);

   agregar(esfera);

   NodoGrafoEscena *patas_superiores = new NodoGrafoEscena();
   unsigned ind_pat_sup2 = patas_superiores->agregar(MAT_Traslacion({-2.0,0.0,0.0}));
   unsigned ind_pat_sup1 = patas_superiores->agregar(MAT_Rotacion(0.0,{0,0,1}));
   patas_superiores->agregar(MAT_Escalado(2.0,0.3,0.3));
   patas_superiores->agregar(MAT_Rotacion(-90,{0,0,1}));
   patas_superiores->agregar(cilindro);

   agregar(patas_superiores);

   for(unsigned int i = 1; i <= n; ++i) {
      agregar(MAT_Rotacion(360.0/(n*1.0),{0,1,0}));
      agregar(patas_superiores);
   }

   NodoGrafoEscena *patas_inferiores = new NodoGrafoEscena();
   unsigned ind_pat_inf2 = patas_inferiores->agregar(MAT_Traslacion({-2.0,0.0,0.0}));
   unsigned ind_pat_inf1 = patas_inferiores->agregar(MAT_Rotacion(0.0,{0,0,1}));
   patas_inferiores->agregar(MAT_Escalado(2.0,0.3,0.3));
   patas_inferiores->agregar(MAT_Rotacion(-90,{0,0,1}));
   patas_inferiores->agregar(cilindro);

   agregar(patas_inferiores);

   for(unsigned int i = 1; i <= n; ++i) {
      agregar(MAT_Rotacion(360.0/(n*1.0),{0,1,0}));
      agregar(patas_inferiores);
   }

   matr1 = esfera->leerPtrMatriz(ind_esf);
   matr2 = patas_superiores->leerPtrMatriz(ind_pat_sup1);
   matr3 = patas_superiores->leerPtrMatriz(ind_pat_sup2);
   matr4 = patas_inferiores->leerPtrMatriz(ind_pat_inf1);
   matr5 = patas_inferiores->leerPtrMatriz(ind_pat_inf2);
}

void EsferaPatas::fijarVeloc1(const float veloc){
   *matr1 = MAT_Traslacion({0.0,abs(5*sin(veloc)),0.0});
}

void EsferaPatas::fijarVeloc2(const float veloc){
   *matr2 = MAT_Rotacion(90*abs(sin(veloc)),{0,0,1});
}

void EsferaPatas::fijarVeloc3(const float veloc){
   *matr3 =  MAT_Traslacion({-2+2*abs(sin(veloc)),0,0});
}

void EsferaPatas::fijarVeloc4(const float veloc){
   *matr4 = MAT_Rotacion(-90*abs(sin(veloc)),{0,0,1});
}

void EsferaPatas::fijarVeloc5(const float veloc){
   *matr5 =  MAT_Traslacion({-2+2*abs(sin(veloc)),0,0});
}

unsigned EsferaPatas::leerNumParametros() const {
   return 5;
}

void EsferaPatas::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {
   case 0: {
      fijarVeloc1(veloc1*t_sec);
      break;
   }
   case 1:
      fijarVeloc2(veloc2*t_sec);
      break;
   case 2:
      fijarVeloc3(veloc3*t_sec);
      break;
   case 3:
      fijarVeloc4(veloc4*t_sec);
      break;
   case 4:
      fijarVeloc5(veloc5*t_sec);
      break;
   default:
      break;
   }
}

// -----------------------------------------------------------------------------
// Clase 'NodoGrafoCubo24

NodoGrafoCubo24::NodoGrafoCubo24() {

   ponerNombre( std::string("Grafo Cubo24") );

   agregar(new Material(new Textura("window-icon.jpg"), 1.0, 1.0, 1.0, 1.0));
   agregar(new Cubo24());
}

// -----------------------------------------------------------------------------
// Clase 'NodoDiscoP4
NodoDiscoP4::NodoDiscoP4(int ejr){
   
   if(ejr == 1)
      ponerNombre( std::string("Grafo DiscoP4 Versión 1") );
   if(ejr == 2)
      ponerNombre( std::string("Grafo DiscoP4 Versión 2") );

   agregar(new Material(new Textura("cuadricula.jpg"), 1.0, 1.0, 1.0, 1.0));
   agregar( new MallaDiscoP4(ejr) );
}

// -----------------------------------------------------------------------------
// Clase 'GrafoEsferasP5
GrafoEsferasP5::GrafoEsferasP5() {
   const unsigned
      n_filas_esferas = 8,
      n_esferas_x_fila= 5 ;
   const float
      e = 0.4/n_esferas_x_fila ;

   agregar( MAT_Escalado( e,e,e ));

   for( unsigned i = 0 ; i < n_filas_esferas ; i++ ){
      NodoGrafoEscena * fila_esferas = new NodoGrafoEscena() ;

      for( unsigned j = 0 ; j < n_esferas_x_fila ; j++ ){
         MallaInd * esfera = new Esfera(50,50) ;
         esfera->ponerIdentificador(n_filas_esferas*i+j+1);
         fila_esferas->agregar( MAT_Traslacion({2.2f, 0.0, 0.0 }));
         fila_esferas->agregar( esfera );
      }

      agregar( fila_esferas );
      agregar( MAT_Traslacion( {0.0, 0.0, 5.0} ));
   }
}

// -----------------------------------------------------------------------------
// Clase 'GrafoEsferasP5_2
GrafoEsferasP5_2::GrafoEsferasP5_2() {
   const unsigned
      n_filas_esferas = 8,
      n_esferas_x_fila = 5 ;
   const float
      e = 2.5/n_esferas_x_fila ;

   agregar( MAT_Escalado( e, e, e ));

   for( unsigned i = 0 ; i < n_filas_esferas ; i++ ) {
      NodoGrafoEscena * fila_esferas = new NodoGrafoEscena() ;
      fila_esferas->agregar( MAT_Traslacion( {3.0, 0.0, 0.0} ));

      for( unsigned j = 0 ; j < n_esferas_x_fila ; j++ ){
         MallaInd * esfera = new Esfera(50,50) ;
         esfera->ponerIdentificador(n_filas_esferas*i+j+1);
         fila_esferas->agregar( MAT_Traslacion( {2.5, 0.0, 0.0} ));
         fila_esferas->agregar( esfera );
      }
      
      agregar( fila_esferas );
      agregar( MAT_Rotacion( 360.0/n_filas_esferas, { 0.0, 1.0, 0.0 }));
   }
}
// -----------------------------------------------------------------------------
// EXAMEN 21/11/2022. Ejercicio P3
// Clase 'Coche

Coche::Coche() {

   ponerNombre( std::string("Coche") );

   // Objetos
   Cubo * cubo = new Cubo();
   Cilindro * cilindro = new Cilindro(10, 50);

   // Nodos
   NodoGrafoEscena * llanta = new NodoGrafoEscena();
   llanta->agregar(MAT_Escalado(2,2,2));
   llanta->agregar(cubo);

   NodoGrafoEscena * rueda = new NodoGrafoEscena();
   unsigned ind_giro_rueda = rueda->agregar(MAT_Rotacion(0, {1,0,0}));
   rueda->agregar(MAT_Escalado(0.3,0.3,0.3));
   rueda->agregar(MAT_Rotacion(90, {0,0,1}));
   rueda->agregar(llanta);
   rueda->agregar(MAT_Escalado(2.85,4,2.85));
   rueda->agregar(MAT_Traslacion({0, -0.5, 0}));
   rueda->agregar(cilindro);
   
   NodoGrafoEscena * chasis_coche_bajo = new NodoGrafoEscena();
   chasis_coche_bajo->agregar(MAT_Escalado(3,1,5));
   chasis_coche_bajo->agregar(MAT_Traslacion({0, 1, 0}));
   chasis_coche_bajo->agregar(cubo);

   NodoGrafoEscena * chasis_coche_alto = new NodoGrafoEscena();
   chasis_coche_alto->agregar(MAT_Escalado(2,1,3));
   chasis_coche_alto->agregar(MAT_Traslacion({0, 3, 0}));
   chasis_coche_alto->agregar(cubo);

   NodoGrafoEscena * rueda_trasera1 = new NodoGrafoEscena();
   rueda_trasera1->agregar(MAT_Traslacion({3.6, 0, 3.5}));
   rueda_trasera1->agregar(rueda);

   NodoGrafoEscena * rueda_trasera2 = new NodoGrafoEscena();
   rueda_trasera2->agregar(MAT_Traslacion({-3.6, 0, 3.5}));
   rueda_trasera2->agregar(rueda);

   NodoGrafoEscena * rueda_delantera1 = new NodoGrafoEscena();
   rueda_delantera1->agregar(MAT_Traslacion({3.6, 0, -3.5}));
   rueda_delantera1->agregar(rueda);

   NodoGrafoEscena * rueda_delantera2 = new NodoGrafoEscena();
   rueda_delantera2->agregar(MAT_Traslacion({-3.6, 0, -3.5}));
   rueda_delantera2->agregar(rueda);

   unsigned ind_giro_coche = agregar(MAT_Rotacion(0, {0,1,0}));
   agregar(MAT_Traslacion({7.5, 0, 0}));
   agregar(chasis_coche_alto);
   agregar(chasis_coche_bajo);
   agregar(rueda_trasera1);
   agregar(rueda_trasera2);
   agregar(rueda_delantera1);
   agregar(rueda_delantera2);

   matriz_rot1 = rueda->leerPtrMatriz(ind_giro_rueda);
   matriz_rot2 = leerPtrMatriz(ind_giro_coche);
}

unsigned Coche::leerNumParametros() const {
   return NUM_PARAMS;
}

void Coche::actualizarEstadoParametro(const unsigned iParam, const float t_sec) {
   switch (iParam)
   {
   case 0:
      fijarAnguloGiroRueda(velocidad_giro_rueda*360*t_sec);
      break;
   case 1:
      fijarAnguloGiroCoche(velocidad_giro_coche*360*t_sec);
      break;

   default:
      break;
   }
}

void Coche::fijarAnguloGiroRueda(float alpha) {
   *matriz_rot1 = MAT_Rotacion(alpha, {1,0,0});
}

void Coche::fijarAnguloGiroCoche(float beta) {
   *matriz_rot2 = MAT_Rotacion(beta, {0,1,0});
}

// -----------------------------------------------------------------------------
// EXAMEN 24/01/2023. Ejercicio P4
// Clase 'NodoEXP4

NodoEXP4::NodoEXP4() {

   ponerNombre( std::string("NodoEXP4") );

   agregar(new Material(new Textura("textura-exp4-v2.jpg"), 0.5, 0.5, 0.5, 80));
   agregar(new MallaEXP4());
}

// -----------------------------------------------------------------------------
// EXAMEN 24/01/2023. Ejercicio P5
// Clase 'EsferaEXP5

EsferaEXP5::EsferaEXP5(unsigned n) {

   ponerNombre( std::string("EsferaEXP5") );

   assert(n > 3);

   // Objetos
   MallaRevol * esfera = new Esfera(50,50) ;

   // Nodo
   ponerColor({1,1,1});
   agregar(MAT_Traslacion({1,0,0}));
   agregar(MAT_Escalado(float(M_PI/n), float(M_PI/n), float(M_PI/n)));
   agregar(esfera);
}

// Clase 'AnilloEXP5

AnilloEXP5::AnilloEXP5(unsigned n) {

   ponerNombre( std::string("AnilloEXP5") );

   assert(n > 3);

   // Nodos

   for(unsigned int i = 0; i < n; ++i) {
      NodoGrafoEscena * esfera_exp5 = new EsferaEXP5(n) ;
      esfera_exp5->ponerIdentificador(i+1);
      agregar(MAT_Rotacion(float(360/n), {0,1,0}));
      agregar(esfera_exp5);
   }
}