// Nombre: Juan Manuel, Apellidos: Rodríguez Gómez, Titulación: GIM
// Email: juanmaarg6@correo.ugr.es, DNI: 49559494Z

// *********************************************************************
// **
// ** Informática Gráfica, curso 2020-21
// ** Declaraciones de la clase Objeto3D.hpp
// **
// *********************************************************************

#include "ig-aux.h"
#include "malla-ind.h"   // declaración de 'ContextoVis'
#include "lector-ply.h"

// *****************************************************************************
// funciones auxiliares

// *****************************************************************************
// métodos de la clase MallaInd.

MallaInd::MallaInd()
{
   // nombre por defecto
   ponerNombre("malla indexada, anónima");
}
// -----------------------------------------------------------------------------

MallaInd::MallaInd( const std::string & nombreIni )
{
   // 'identificador' puesto a 0 por defecto, 'centro_oc' puesto a (0,0,0)
   ponerNombre(nombreIni) ;
}

//-----------------------------------------------------------------------------
// calcula la tabla de normales de triángulos una sola vez, si no estaba calculada

void MallaInd::calcularNormalesTriangulos()
{

   // si ya está creada la tabla de normales de triángulos, no es necesario volver a crearla
   const unsigned nt = triangulos.size() ;
   assert( 1 <= nt );
   if ( 0 < nor_tri.size() )
   {
      assert( nt == nor_tri.size() );
      return ;
   }

   // COMPLETAR: Práctica 4: creación de la tabla de normales de triángulos
   // ....
   for(unsigned int i = 0; i < nt; ++i) {
      Tupla3f a = vertices[triangulos[i](1)] - vertices[triangulos[i](0)];
      Tupla3f b = vertices[triangulos[i](2)] - vertices[triangulos[i](0)];

      Tupla3f mc = a.cross(b);
      Tupla3f nc;
      
      if(mc.lengthSq() != 0)
         nc = mc.normalized();
      else
         nc = {0.0f,0.0f,0.0f};

      nor_tri.push_back(nc);
   }
}


// -----------------------------------------------------------------------------
// calcula las dos tablas de normales

void MallaInd::calcularNormales()
{
   // COMPLETAR: en la práctica 4: calculo de las normales de la malla
   // se debe invocar en primer lugar 'calcularNormalesTriangulos'
   // .......
   calcularNormalesTriangulos();

   for(unsigned int i = 0; i < vertices.size(); ++i)
      nor_ver.push_back({0, 0, 0});

   for(unsigned int i = 0; i < triangulos.size(); ++i) {
      nor_ver[triangulos[i](0)] = nor_ver[triangulos[i](0)] + nor_tri[i];
      nor_ver[triangulos[i](1)] = nor_ver[triangulos[i](1)] + nor_tri[i];
      nor_ver[triangulos[i](2)] = nor_ver[triangulos[i](2)] + nor_tri[i];
   }

   for(unsigned int i = 0; i < nor_ver.size(); ++i)
      if(nor_ver[i].lengthSq() != 0.0f)
         nor_ver[i] = nor_ver[i].normalized();

}



// --------------------------------------------------------------------------------------------

void MallaInd::visualizarGL( ContextoVis & cv )
{

   if ( cv.visualizando_normales )
   {  
      visualizarNormales( cv );
      return ;
   }
   
   using namespace std ;
   assert( cv.cauce != nullptr );
   CError();


   if ( triangulos.size() == 0 || vertices.size() == 0 )
   {  cout << "advertencia: intentando dibujar malla vacía '" << leerNombre() << "'" << endl << flush ;
      return ;
   }

   // guardar el color previamente fijado y fijar el color del objeto actual
   const Tupla4f color_previo = leerFijarColVertsCauce( cv );

   // COMPLETAR: práctica 1: si el nombre del VAO es 0, crear el VAO con sus VBOs:
   //   * en primer lugar se crea y activa el VAO , con 'CrearVAO'.
   //   * después se añade el VBO con la tabla de coordenadas de posición, 'CrearVBOAtrib'.
   //   * se añade el VBO con la tabla de índices (la tabla de triángulos), con 'CrearVBOInd'.
   //   * finalmente se añaden al VAO los VBOs con tablas de atributos (opcionaes) que haya, con 'CrearVBOAtrib'.
   // si el VAO ya está creado, (nombre_vao > 0), activarlo, con 'glBindVertexArray'
   //
   //  hay que tener en cuenta que el nombre del VAO y los nombres de losVBOs deben quedar en las correspondientes 
   //  variables de instancia. Estos nombres son los devueltos por las 
   //  funciones 'CrearVAO', 'CrearVBOAtrib' y 'CrearVBOInd'.
   //
   if(nombre_vao == 0) {
      nombre_vao = CrearVAO();
      nombre_vbo_pos = CrearVBOAtrib(ind_atrib_posiciones, vertices);
      nombre_vbo_tri = CrearVBOInd(triangulos);

      if(col_ver.size() > 0)
         nombre_vbo_col = CrearVBOAtrib(ind_atrib_colores, col_ver);

      if(nor_ver.size() > 0)
         nombre_vbo_nor = CrearVBOAtrib(ind_atrib_normales, nor_ver);

      if(nor_tri.size() > 0)
         nombre_vbo_nor = CrearVBOAtrib(ind_atrib_normales, nor_tri);

      if(cc_tt_ver.size() > 0)
         nombre_vbo_cct = CrearVBOAtrib(ind_atrib_coord_text, cc_tt_ver);
      
      CError();
   }
   else {
      glBindVertexArray(nombre_vao);
   }

   // COMPLETAR: práctica 1: visualizar con 'glDrawElements' y desactivar VAO.
   glDrawElements(GL_TRIANGLES, 3*triangulos.size(), GL_UNSIGNED_INT, 0);
   glBindVertexArray(0);

   // restaurar el color previamente fijado
   cv.cauce->fijarColor( color_previo );
}


// -----------------------------------------------------------------------------
// visualizar pura y simplemente la geometría, sin colores, normales, coord. text. etc...
// (se supone que el estado de OpenGL está fijado antes de esta llamada de alguna forma adecuada)

void MallaInd::visualizarGeomGL( ContextoVis & cv )
{
   // COMPLETAR: práctica 1: asegurarnos de que el VAO de geometría está creado y activado
   // ....
   if(nombre_vao_geo == 0) {
      nombre_vao_geo = CrearVAO();

      glBindBuffer(GL_ARRAY_BUFFER, nombre_vbo_pos);
      glVertexAttribPointer(ind_atrib_posiciones, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(ind_atrib_posiciones);
      glBindBuffer(GL_ARRAY_BUFFER, nombre_vbo_pos);

      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, nombre_vbo_tri);

      CError();
   }
   else {
      glBindVertexArray(nombre_vao_geo);
   }


   // COMPLETAR: práctica 1. Visualizar la malla y desactivar VAO
   // ....
   glDrawElements(GL_TRIANGLES, 3*triangulos.size(), GL_UNSIGNED_INT, 0);
   glBindVertexArray(0);

}

// -----------------------------------------------------------------------------
void MallaInd::visualizarNormales( ContextoVis & cv )
{
   using namespace std ;

   if ( nor_ver.size() == 0 )
   {
      cout << "Advertencia: intentando dibujar normales de una malla que no tiene tabla (" << leerNombre() << ")." << endl ;
      return ;
   }  
   if ( nombre_vao_normales == 0 )
   {  
      for( unsigned i = 0 ; i < vertices.size() ; i++ )
      {  
         segmentos_normales.push_back( vertices[i] );
         segmentos_normales.push_back( vertices[i]+ 0.35f*(nor_ver[i]) );
      }
      nombre_vao_normales = CrearVAO();
      CrearVBOAtrib( ind_atrib_posiciones, segmentos_normales );   
   }
   else 
      glBindVertexArray( nombre_vao_normales );

   cv.cauce->fijarColor( 1.0, 0.5, 0.2 ); // fijar el color (rojo), con el VAO activado.
   glDrawArrays( GL_LINES, 0, segmentos_normales.size() );
   glBindVertexArray( 0 );
   CError();
}

// ****************************************************************************
// Clase 'MallaPLY'

MallaPLY::MallaPLY( const std::string & nombre_arch )
{
   ponerNombre( std::string("malla leída del archivo '") + nombre_arch + "'" );

   // COMPLETAR: práctica 2: leer archivo PLY e inicializar la malla
   // ..........................
   LeerPLY(nombre_arch, vertices, triangulos);


   // COMPLETAR: práctica 4: invocar  a 'calcularNormales' para el cálculo de normales
   // .................
   calcularNormales();
}

// ****************************************************************************
// Clase 'Cubo

Cubo::Cubo()
:  MallaInd( "Cubo 8 Vértices" )
{

   vertices =
      {  { -1.0, -1.0, -1.0 }, // 0
         { -1.0, -1.0, +1.0 }, // 1
         { -1.0, +1.0, -1.0 }, // 2
         { -1.0, +1.0, +1.0 }, // 3
         { +1.0, -1.0, -1.0 }, // 4
         { +1.0, -1.0, +1.0 }, // 5
         { +1.0, +1.0, -1.0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
      } ;



   triangulos =
      {  {0,1,3}, {0,3,2}, // X-
         {4,7,5}, {4,6,7}, // X+ (+4)

         {0,5,1}, {0,4,5}, // Y-
         {2,3,7}, {2,7,6}, // Y+ (+2)

         {0,6,4}, {0,2,6}, // Z-
         {1,5,7}, {1,7,3}  // Z+ (+1)
      } ;

   calcularNormales();
}

// ****************************************************************************
// Clase 'CuboTejado'

CuboTejado::CuboTejado()
:  MallaInd( "Cubo Tejado 8 Vértices" )
{

   vertices =
      {  { -1.0, -1.0, -1.0 }, // 0
         { -1.0, -1.0, +1.0 }, // 1
         { -1.0, +1.0, -1.0 }, // 2
         { -1.0, +1.0, +1.0 }, // 3
         { +1.0, -1.0, -1.0 }, // 4
         { +1.0, -1.0, +1.0 }, // 5
         { +1.0, +1.0, -1.0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
         { +0.0, +2.0, +0.0 }, // 8
      } ;

   for( Tupla3f & v : vertices )
      v = 2.0f*v +Tupla3f({0.0,2.0,0.0});



   triangulos =
      {  {0,1,3}, {0,3,2}, // X-
         {4,7,5}, {4,6,7}, // X+ (+4)

         {0,5,1}, {0,4,5}, // Y-
         //{2,3,7}, {2,7,6}, // Y+ (+2)   // quito cara superior
         {2,3,8}, {3,7,8}, {7,6,8}, {6,2,8}, // añado tejado 

         {0,6,4}, {0,2,6}, // Z-
         {1,5,7}, {1,7,3}  // Z+ (+1)
      } ;
}

// ****************************************************************************
// Clase 'Tetraedro

Tetraedro::Tetraedro()
:  MallaInd( "Tetraedro 4 Vértices" )
{

   vertices =
      {  { -1.0,  0.0, -1.0/sqrt(2)}, // 0
         {  1.0,  0.0, -1.0/sqrt(2)}, // 1
         {  0.0, -1.0,  1.0/sqrt(2)}, // 2
         {  0.0,  1.0,  1.0/sqrt(2)}, // 3
      } ;



   triangulos =
      {  {0,1,2}, {0,2,3},
         {0,1,3}, {1,2,3},
      } ;

   ponerColor( Tupla3f(0.5, 1, 0.5) );

   calcularNormales();
}

// ****************************************************************************
// Clase 'CuboColores

CuboColores::CuboColores()
:  MallaInd( "Cubo Colores 8 Vértices" )
{

   vertices =
      {  { -1.0, -1.0, -1.0 }, // 0
         { -1.0, -1.0, +1.0 }, // 1
         { -1.0, +1.0, -1.0 }, // 2
         { -1.0, +1.0, +1.0 }, // 3
         { +1.0, -1.0, -1.0 }, // 4
         { +1.0, -1.0, +1.0 }, // 5
         { +1.0, +1.0, -1.0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
      } ;



   triangulos =
      {  {0,1,3}, {0,3,2}, // X-
         {4,7,5}, {4,6,7}, // X+ (+4)

         {0,5,1}, {0,4,5}, // Y-
         {2,3,7}, {2,7,6}, // Y+ (+2)

         {0,6,4}, {0,2,6}, // Z-
         {1,5,7}, {1,7,3}  // Z+ (+1)
      } ;

   col_ver =
      {  {    0,    0,    0 }, // 0
         {    0,    0, +1.0 }, // 1
         {    0, +1.0,    0 }, // 2
         {    0, +1.0, +1.0 }, // 3
         { +1.0,    0,    0 }, // 4
         { +1.0,    0, +1.0 }, // 5
         { +1.0, +1.0,    0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
      } ;
}

// ****************************************************************************
// Clase 'EstrellaZ

EstrellaZ::EstrellaZ(unsigned n)
:  MallaInd( "Estrella Z" )
{
   assert(n > 1);
   
   // Vértices
   vertices.push_back( {0.5, 0.5, 0} );   // Centro de la estrella

   
   for(unsigned int i = 0; i < 2*n; i += 2) {   // Creamos todos los vértices de la estrella de 2 en 2
      vertices.push_back( {float(cos(i*M_PI/n)/2 + 0.5), float(sin(i*M_PI/n)/2 + 0.5), 0} );
      vertices.push_back( {float(cos((i+1)*M_PI/n)/4 + 0.5), float(sin((i+1)*M_PI/n)/4 + 0.5), 0} );
   }

   // Triángulos
   for(unsigned int i = 0; i < 2*n; i++) {
      triangulos.push_back( {0, i, i+1} );
   }

   triangulos.push_back( {0, 2*n, 1} );

   // Colores
   col_ver.push_back( {1, 1, 1} );  // Color del centro

   for(unsigned int i = 0; i < 2*n; i += 2) {   // Colores de los vértices de la estrella de 2 en 2
      col_ver.push_back( {float(cos(i*M_PI/n)/2 + 0.5), float(sin(i*M_PI/n)/2 + 0.5), 0} );
      col_ver.push_back( {float(cos((i+1)*M_PI/n)/4 + 0.5), float(sin((i+1)*M_PI/n)/4 + 0.5), 0} );
   }
}

// ****************************************************************************
// Clase 'CasaX

CasaX::CasaX()
:  MallaInd( "Casa X" )
{

   vertices =
      {  {    0,    0,     0 }, // 0
         {    0,    0,  +0.5 }, // 1
         {    0, +0.5,     0 }, // 2
         {    0, +0.5,  +0.5 }, // 3
         { +1.0,    0,     0 }, // 4
         { +1.0,    0,  +0.5 }, // 5
         { +1.0, +0.5,     0 }, // 6
         { +1.0, +0.5,  +0.5 }, // 7
         {    0, +0.8, +0.25 }, // 8   Vértice para el tejado
         { +1.0, +0.8, +0.25 }  // 9   Vértice para el tejado
      } ;



   triangulos =
      {  {0,1,3}, {0,3,2}, // X-
         {4,7,5}, {4,6,7}, // X+ (+4)

         // {0,5,1}, {0,4,5}, // Y-
         // {2,3,7}, {2,7,6}, // Y+ (+2)

         {0,6,4}, {0,2,6}, // Z-
         {1,5,7}, {1,7,3},  // Z+ (+1)

         // Triángulos del tejado
         {2,3,8}, {3,8,9}, {7,3,9},
         {7,9,6}, {6,9,8}, {6,8,2}
      } ;

   col_ver =
      {  {    0,    0,     0 }, // 0
         {    0,    0,  +0.5 }, // 1
         {    0, +0.5,     0 }, // 2
         {    0, +0.5,  +0.5 }, // 3
         { +1.0,    0,     0 }, // 4
         { +1.0,    0,  +0.5 }, // 5
         { +1.0, +0.5,     0 }, // 6
         { +1.0, +0.5,  +0.5 }, // 7
         {    0, +0.8, +0.25 }, // 8   Vértice para el tejado
         { +1.0, +0.8, +0.25 }  // 9   Vértice para el tejado
      } ;
}

// ****************************************************************************
// Clase 'MallaTriangulo

MallaTriangulo::MallaTriangulo()
:  MallaInd( "Malla Triángulo" )
{

   vertices =
      {  {    0,      0,   0 },  // 0
         { +1.0,      0,   0 },  // 1
         {    0, sqrt(2),  0 }   // 2
      } ;



   triangulos =
      {  
         {0,1,2}
      } ;
}

// ****************************************************************************
// Clase 'MallaCuadrado

MallaCuadrado::MallaCuadrado()
:  MallaInd( "Malla Cuadrado" )
{

   vertices =
      {  { -1.0,   -1.0,   0 }, // 0
         { -1.0,   +1.0,   0 }, // 1
         { +1.0,   -1.0,   0 }, // 2
         { +1.0,   +1.0,   0 }  // 3
      } ;



   triangulos =
      {  
         {0,1,2}, {1,2,3}
      } ;
}

// ****************************************************************************
// Clase 'MallaPiramideL

MallaPiramideL::MallaPiramideL()
:  MallaInd( "Malla Pirámide L" )
{

   vertices =
      {  {    0,      0,      0 }, // 0
         {    0,      0,   +1.0 }, // 1
         { +0.5,      0,   +1.0 }, // 2
         { +0.5,      0,   +0.5 }, // 3
         { +1.0,      0,   +0.5 }, // 4
         { +1.0,      0,      0 }, // 5
         { +0.5,   +1.0,   +0.5 }, // 6   Vértice de la punta de la pirámide
      } ;



   triangulos =
      {  
         {1,2,3}, {0,1,5}, {3,4,5},  // Base de la pirámide
         {0,1,6}, {1,2,6}, {2,3,6}, {3,4,6}, {4,5,6}, {5,0,6}  // Caras laterales de la pirámide
      } ;
}

// ****************************************************************************
// Clase 'PiramideEstrellaZ

PiramideEstrellaZ::PiramideEstrellaZ(unsigned n)
:  MallaInd( "Pirámide Estrella Z" )
{
   assert(n > 1);

   // Vértices
   vertices.push_back( {0.5, 0.5, 0} );   // Centro de la estrella

   
   for(unsigned int i = 0; i < 2*n; i += 2) {   // Creamos todos los vértices de la estrella de 2 en 2
      vertices.push_back( {float(cos(i*M_PI/n)/2 + 0.5), float(sin(i*M_PI/n)/2 + 0.5), 0} );
      vertices.push_back( {float(cos((i+1)*M_PI/n)/4 + 0.5), float(sin((i+1)*M_PI/n)/4 + 0.5), 0} );
   }

   vertices.push_back( {0.5, 0.5, 0.5} );   // Ápice de la pirámide

   // Triángulos de la base de la pirámide
   for(unsigned int i = 0; i < 2*n; i++) {
      triangulos.push_back( {0, i, i+1} );
   }

   triangulos.push_back( {0, 2*n, 1} );

   // Triángulos de los laterales de la pirámide
   for(unsigned int i = 0; i < 2*n; i++) {
      triangulos.push_back( {2*n+1, i, i+1} );
   }

   triangulos.push_back( {2*n+1, 2*n, 1} );

   // Colores
   col_ver.push_back( {1, 1, 1} );  // Color del centro

   for(unsigned int i = 0; i < 2*n; i += 2) {   // Colores de los vértices de la base de la pirámide
      col_ver.push_back( {float(std::cos(i*M_PI/n)/2 + 0.5), float(std::sin(i*M_PI/n)/2 + 0.5), 0} );
      col_ver.push_back( {float(std::cos((i+1)*M_PI/n)/4 + 0.5), float(std::sin((i+1)*M_PI/n)/4 + 0.5), 0} );
   }

   col_ver.push_back( {1, 1, 1} );  // Color de la punta de la pirámide
}

// ****************************************************************************
// Clase 'RejillaY

RejillaY::RejillaY(unsigned m, unsigned n)
:  MallaInd( "Rejilla Y" )
{
   assert(m > 1);
   assert(n > 1);

   // Vértices
   for(unsigned int i = 0; i < n ; ++i)
      for(unsigned int j = 0; j < m ; ++j)
         vertices.push_back( {float(i)/(n-1), 0, float(j)/(m-1)} );

   // Triángulos
   for(unsigned int i = 0; i < n-1 ; ++i)
      for(unsigned int j = 0; j < m-1 ; ++j) {
         triangulos.push_back( {m*i+j, m*(i+1)+j, m*i+(j+1)} );   
         triangulos.push_back( {m*(i+1)+j, m*i+(j+1), m*(i+1)+(j+1)} );   
      }

   // Colores
   for(unsigned int i = 0; i < n ; ++i)
      for(unsigned int j = 0; j < m ; ++j)
         col_ver.push_back( {float(i)/(n-1), 0, float(j)/(m-1)} );
}

// ****************************************************************************
// Clase 'MallaTorre

MallaTorre::MallaTorre(unsigned n)
:  MallaInd( "Malla Torre" )
{
   assert(n > 1);

   // Vértices
   for(unsigned int i = 0; i <= n ; ++i) {
         vertices.push_back( {-0.5, float(i), -0.5} );
         vertices.push_back( {-0.5, float(i), +0.5} );
         vertices.push_back( {+0.5, float(i), +0.5} );
         vertices.push_back( {+0.5, float(i), -0.5} );
   }

   // Triángulos

   triangulos.push_back( {0,3,4} );

   for(unsigned int i = 0; i < 4*n-1 ; ++i) {
      triangulos.push_back( {i, i+1, i+4} );
      triangulos.push_back( {i+1, i+4, i+5} );
   }

   triangulos.push_back( {4*n,4*(n-1)+3,4*n+3} );
}

// ****************************************************************************
// Clase 'Corazon

Corazon::Corazon()
:  MallaInd( "Corazon" )
{
   // Vértices
   vertices.push_back( {0,0,0} );

   for(unsigned int i = 0; i <= 100 ; ++i) {
      float angulo = (M_PI/50.0)*float(i);
      vertices.push_back( { ( 12*sin(angulo) - 4*sin(3*angulo) ) / 10.0, 
                            ( 13*cos(angulo) - 5*cos(2*angulo) - 2*cos(3*angulo) - cos(4*angulo) ) / 10.0, 
                            0 } );
   }

   // Triángulos
   for(unsigned int i = 0; i < 100 ; ++i)
      triangulos.push_back( {0, i, i+1} );

   ponerColor( {1, 0, 0} );

}

// ****************************************************************************
// Clase 'Tunel

Tunel::Tunel()
:  MallaInd( "Tunel" )
{

   vertices =
      {  {    0,    0,     0 }, // 0
         {    0,    0,  +0.5 }, // 1
         {    0, +0.5,     0 }, // 2
         {    0, +0.5,  +0.5 }, // 3
         { +1.0,    0,     0 }, // 4
         { +1.0,    0,  +0.5 }, // 5
         { +1.0, +0.5,     0 }, // 6
         { +1.0, +0.5,  +0.5 }, // 7
         {    0, +0.8, +0.25 }, // 8   Vértice para el tejado
         { +1.0, +0.8, +0.25 }  // 9   Vértice para el tejado
      } ;



   triangulos =
      {  //{0,1,3}, {0,3,2}, // X-
         //{4,7,5}, {4,6,7}, // X+ (+4)

         // {0,5,1}, {0,4,5}, // Y-
         // {2,3,7}, {2,7,6}, // Y+ (+2)

         {0,6,4}, {0,2,6}, // Z-
         {1,5,7}, {1,7,3},  // Z+ (+1)

         // Triángulos del tejado
         {2,3,8}, {3,8,9}, {7,3,9},
         {7,9,6}, {6,9,8}, {6,8,2}
      } ;
}

// ****************************************************************************
// Clase 'Poligono

Poligono::Poligono(unsigned n)
:  MallaInd( "Poligono" )
{
    assert(n > 1);
   
    // Vértices
    vertices.push_back({0,0,0});
    for(unsigned int i = 0; i < n; ++i)  
        vertices.push_back( {float(cos(i*2*M_PI/(n))), float(sin(i*2*M_PI/(n))), 0} );

    // Triángulos
    for(unsigned int i = 0; i < n; ++i) 
        triangulos.push_back( {0, i, i+1} );

      triangulos.push_back({0,1,n});
}


// ****************************************************************************
// Clase 'Cubo24

Cubo24::Cubo24(){
   vertices =
      {  { -1.0, -1.0, -1.0 }, // 0.0 
         { -1.0, -1.0, -1.0 }, // 0.1 
         { -1.0, -1.0, -1.0 }, // 0.2
         { -1.0, -1.0, +1.0 }, // 1.3 
         { -1.0, -1.0, +1.0 }, // 1.4 
         { -1.0, -1.0, +1.0 }, // 1.5 
         { -1.0, +1.0, -1.0 }, // 2.6 
         { -1.0, +1.0, -1.0 }, // 2.7
         { -1.0, +1.0, -1.0 }, // 2.8
         { -1.0, +1.0, +1.0 }, // 3.9
         { -1.0, +1.0, +1.0 }, // 3.10
         { -1.0, +1.0, +1.0 }, // 3.11 
         { +1.0, -1.0, -1.0 }, // 4.12
         { +1.0, -1.0, -1.0 }, // 4.13
         { +1.0, -1.0, -1.0 }, // 4.14
         { +1.0, -1.0, +1.0 }, // 5.15
         { +1.0, -1.0, +1.0 }, // 5.16
         { +1.0, -1.0, +1.0 }, // 5.17
         { +1.0, +1.0, -1.0 }, // 6.18
         { +1.0, +1.0, -1.0 }, // 6.19
         { +1.0, +1.0, -1.0 }, // 6.20
         { +1.0, +1.0, +1.0 }, // 7.21
         { +1.0, +1.0, +1.0 }, // 7.22
         { +1.0, +1.0, +1.0 }, // 7.23
      } ;

   triangulos =
      {  {9,0,3}, {0,9,6}, // X-
         {10,4,15}, {15,21,10}, // X+ (+4)

         {22,16,18}, {16,12,18}, // Y-
         {13,1,19}, {1,7,19}, // Y+ (+2)

         {8,11,20}, {11,23,20}, // Z-
         {17,5,2}, {17,2,14}  // Z+ (+1)
      };

   cc_tt_ver = 
      {  {0.0, 1.0},     // 1 
         {1.0, 1.0},     // 4 
         {1.0, 0.0},     // 6 
         {1.0, 1.0},     // 1 
         {0.0, 1.0},     // 2
         {1.0, 1.0},     // 6
         {0.0, 0.0},     // 1 
         {1.0, 0.0},     // 4
         {1.0, 0.0},     // 5  
         {1.0, 0.0},     // 1
         {0.0, 0.0},     // 2 
         {0.0, 0.0},     // 5
         {1.0, 1.0},     // 3
         {0.0, 1.0},     // 4   
         {0.0, 0.0},     // 6
         {1.0, 1.0},     // 2  
         {0.0, 1.0},     // 3
         {0.0, 1.0},     // 6
         {1.0, 0.0},     // 3 
         {0.0, 0.0},     // 4 
         {1.0, 1.0},     // 5
         {1.0, 0.0},     // 2 
         {0.0, 0.0},     // 3 
         {0.0, 1.0},     // 5  
      };

   calcularNormales();
}

// ****************************************************************************
// Clase 'MallaDiscoP4

MallaDiscoP4::MallaDiscoP4(int ejr) {
   ponerColor({1.0, 1.0, 1.0});

   const unsigned ni = 23, nj = 31 ;

   for( unsigned i= 0 ; i < ni ; i++ )
      for( unsigned j= 0 ; j < nj ; j++ ) {
         const float
            fi = float(i)/float(ni-1),
            fj = float(j)/float(nj-1),
            ai = 2.0*M_PI*fi,
            x = fj * cos( ai ),
            y = fj * sin( ai ),
            z = 0.0 ;
         vertices.push_back({ x, y, z });
         // Ejercicio Adicional 1 de la P4
         if(ejr == 1)                     
            cc_tt_ver.push_back({float(x/2.0 + 0.5), float(y/2.0 + 0.5)});
         // Ejercicio Adicional 2 de la P4
         if(ejr == 2)
            cc_tt_ver.push_back({fi, fj});
      }

   for( unsigned i= 0 ; i < ni-1 ; i++ )
      for( unsigned j= 0 ; j < nj-1 ; j++ ) {
         triangulos.push_back({ i*nj+j, i*nj+(j+1), (i+1)*nj+(j+1) });
         triangulos.push_back({ i*nj+j, (i+1)*nj+(j+1), (i+1)*nj+j });
      }
}

// ****************************************************************************
// EXAMEN 21/11/2022. Ejercicio P1
// Clase 'CuboPuntas

CuboPuntas::CuboPuntas()
:  MallaInd( "Cubo Puntas" )
{

   vertices =
      {  { -1.0, -1.0, -1.0 }, // 0
         { -1.0, -1.0, +1.0 }, // 1
         { -1.0, +1.0, -1.0 }, // 2
         { -1.0, +1.0, +1.0 }, // 3
         { +1.0, -1.0, -1.0 }, // 4
         { +1.0, -1.0, +1.0 }, // 5
         { +1.0, +1.0, -1.0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
         { +6.0,  0.0,  0.0 }, // 8
         {  0.0, +6.0,  0.0 }, // 9
         {  0.0, -6.0,  0.0 }, // 10
         { -6.0,  0.0,  0.0 }, // 11

      } ;



   triangulos =
      {  //{0,1,3}, {0,3,2}, // X-
         //{4,7,5}, {4,6,7}, // X+ (+4)

         //{0,5,1}, {0,4,5}, // Y-
         //{2,3,7}, {2,7,6}, // Y+ (+2)

         {0,6,4}, {0,2,6}, // Z-
         {1,5,7}, {1,7,3},  // Z+ (+1)

         // Pirámides
         {3,7,9}, {7,6,9}, {6,2,9}, {2,3,9},
         {6,7,8}, {4,6,8}, {4,5,8}, {5,7,8},
         {0,1,10}, {1,5,10}, {4,5,10}, {0,4,10},
         {0,1,11}, {1,3,11}, {2,3,11}, {2,0,11}
      } ;

   col_ver =
      {  {    0,    0,    0 }, // 0
         {    0,    0,    0 }, // 1
         {    0,    0, +1.0 }, // 2
         {    0,    0, +1.0 }, // 3
         { +1.0, +1.0,    0 }, // 4
         { +1.0, +1.0,    0 }, // 5
         { +1.0,    0, +1.0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
         { +1.0, +1.0,    0 }, // 8
         {    0,    0, +1.0 }, // 9
         {    0,    0,    0 }, // 10
         {    0,    0,    0 }, // 11
      } ;
}

// ****************************************************************************
// EXAMEN 24/01/2023. Ejercicio P4
// Clase 'MallaEXP4

MallaEXP4::MallaEXP4()
:  MallaInd( "MallaEXP4" )
{

   vertices =
      {  
         {  0.0,  1.0,  1.0/sqrt(2)}, // 0.1 (0)
         { -1.0,  0.0, -1.0/sqrt(2)}, // 1.1 (1)
         {  1.0,  0.0, -1.0/sqrt(2)}, // 2.1 (2)

         {  0.0,  1.0,  1.0/sqrt(2)}, // 0.2 (3)
         {  0.0, -1.0,  1.0/sqrt(2)}, // 3.1 (4)
         { -1.0,  0.0, -1.0/sqrt(2)}, // 1.2 (5)

         {  0.0,  1.0,  1.0/sqrt(2)}, // 0.3 (6)
         {  1.0,  0.0, -1.0/sqrt(2)}, // 2.2 (7)
         {  0.0, -1.0,  1.0/sqrt(2)}, // 3.2 (8)

         { -1.0,  0.0, -1.0/sqrt(2)}, // 1.3 (9)
         {  1.0,  0.0, -1.0/sqrt(2)}, // 2.3 (10)
         {  0.0, -1.0,  1.0/sqrt(2)}, // 3.3 (11)
      } ;



   triangulos =
      {  
         {0,1,2}, {3,4,5},
         {6,7,8}, {9,10,11}
      } ;

   cc_tt_ver =
      {
         {0.5, 0},     // 0 
         {1, 1},       // 1 
         {0, 1},       // 2 

         {0.5, 0},     // 3
         {1, 1},       // 4 
         {0, 1},       // 5 

         {0.5, 0},     // 6 
         {1, 1},       // 7 
         {0, 1},       // 8 

         {0.5, 0},     // 9 
         {1, 1},       // 10 
         {0, 1},       // 11
      } ;

   ponerColor( Tupla3f(0.5, 1, 0.5) );

   calcularNormales();
}
// -----------------------------------------------------------------------------------------------

