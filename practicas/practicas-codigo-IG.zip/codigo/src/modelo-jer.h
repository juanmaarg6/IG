// Nombre: Juan Manuel, Apellidos: Rodríguez Gómez, Titulación: GIM
// Email: juanmaarg6@correo.ugr.es, DNI: 49559494Z

#ifndef MODELO_JER_H
#define MODELO_JER_H

#include "grafo-escena.h"

using namespace std;

// ****************************************************************************
// Clases derivadas de MallaInd
// ****************************************************************************

// --------------------------------------------------------------------
// Clase 'SemiPoligono'

class SemiPoligono : public MallaInd
{
  public:
      SemiPoligono(unsigned n);
};

// --------------------------------------------------------------------
// Clase 'LemniscataXPositivo'

class LemniscataXPositivo : public MallaInd
{
  public:
      LemniscataXPositivo(unsigned n);
} ;

// --------------------------------------------------------------------
// Clase 'TrianguloEquilatero'

class TrianguloEquilatero : public MallaInd
{
  public:
      TrianguloEquilatero();
} ;

// ****************************************************************************
// Clases derivadas de NodoGrafoEscena
// ****************************************************************************

// --------------------------------------------------------------------
// Clase 'Ojos'

class Ojos : public NodoGrafoEscena {
    public:
        Ojos();
};

// --------------------------------------------------------------------
// Clase 'BaseCabeza_Ojos'

class BaseCabeza_Ojos : public NodoGrafoEscena {
    public:
        BaseCabeza_Ojos();
};

// --------------------------------------------------------------------
// Clase 'BaseBoca_Colmillos'

class BaseBoca_Colmillos : public NodoGrafoEscena {
    public:
        BaseBoca_Colmillos();
};

// --------------------------------------------------------------------
// Clase 'BaseCuerpo'

class BaseCuerpo : public NodoGrafoEscena {
    public:
        BaseCuerpo();
};

// --------------------------------------------------------------------
// Clase 'PieIzq_PieDcho'

class PieIzq_PieDcho : public NodoGrafoEscena {
    public:
        PieIzq_PieDcho();
};

// --------------------------------------------------------------------
// Clase 'PartesAntenaDcha'

class PartesAntenaDcha : public NodoGrafoEscena {
    public:
        PartesAntenaDcha();
};

// --------------------------------------------------------------------
// Clase 'PartesAntenaIzq'

class PartesAntenaIzq : public NodoGrafoEscena {
    public:
        PartesAntenaIzq();
};

// --------------------------------------------------------------------
// Clase 'Mano'

class Mano : public NodoGrafoEscena {
    public:
        Mano();
};

// --------------------------------------------------------------------
// Clase 'ParteDeAla'

class ParteDeAla : public NodoGrafoEscena {
    public:
        ParteDeAla();
};

// --------------------------------------------------------------------
// Clase 'AlaSupDcha_AlaSupIzq'

class AlaSupDcha_AlaSupIzq : public NodoGrafoEscena {
    public:
        AlaSupDcha_AlaSupIzq();
};

// --------------------------------------------------------------------
// Clase 'AlaInfDcha_AlaInfIzq'

class AlaInfDcha_AlaInfIzq : public NodoGrafoEscena {
    public:
        AlaInfDcha_AlaInfIzq();
};

// --------------------------------------------------------------------
// Clase 'Butterfree'

class Butterfree : public NodoGrafoEscena {
    private:
        const unsigned NUM_PARAMS = 5;
        Matriz4f * matriz_rot1 = nullptr;
        Matriz4f * matriz_rot2 = nullptr;
        Matriz4f * matriz_rot3 = nullptr;
        Matriz4f * matriz_rot4 = nullptr;
        Matriz4f * matriz_tras = nullptr;
        const float angulo1 = 10;
        const float angulo2 = -20;
        const float angulo3 = 60;
        const float angulo4 = 30;
        const float velocidad_tras = 2;
    public:
        Butterfree();
        unsigned leerNumParametros() const;
        void actualizarEstadoParametro(const unsigned iParam, const float tSec);
        void fijarAnguloGiroAlpha(const float alpha);
        void fijarAnguloGiroBeta(const float beta);
        void fijarAnguloGiroGamma(const float gamma);
        void fijarAnguloGiroDelta(const float delta);
        void fijarTraslacion(float x, float y, float z);
};

#endif // MODELO_JER_H