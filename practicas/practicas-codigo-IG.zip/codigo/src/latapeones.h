// Nombre: Juan Manuel, Apellidos: Rodríguez Gómez, Titulación: GIM
// Email: juanmaarg6@correo.ugr.es, DNI: 49559494Z

#ifndef LATAPEONES_H
#define LATAPEONES_H

#include "grafo-escena.h"

using namespace std;

class Lata : public NodoGrafoEscena {
    public:
        Lata(string textura);
};

class LataPeones : public NodoGrafoEscena {
    public:
        LataPeones();
};

class VariasLatasPeones : public NodoGrafoEscena {
    public:
        VariasLatasPeones();
};

#endif // LATAPEONES_H