// Nombre: Juan Manuel, Apellidos: Rodríguez Gómez, Titulación: GIM
// Email: juanmaarg6@correo.ugr.es, DNI: 49559494Z

// *********************************************************************
// **
// ** Informática Gráfica, curso 2019-20
// ** Implementación de la clase 'MallaRevol'
// **
// *********************************************************************

#include "ig-aux.h"
#include "lector-ply.h"
#include "malla-revol.h"

using namespace std ;

// *****************************************************************************

// Método que crea las tablas de vértices, triángulos, normales y cc.de.tt.
// a partir de un perfil y el número de copias que queremos de dicho perfil.
void MallaRevol::inicializar
(
   const std::vector<Tupla3f> & perfil,     // tabla de vértices del perfil original
   const unsigned               num_copias  // número de copias del perfil
)
{
   // COMPLETAR: Práctica 4: crear tablas de normales 
   vector<Tupla3f> nor_arist_per;           // vector de normales de las aristas del perfil
   vector<Tupla3f> nor_vert_per;            // vector de normales de los vertices del perfil
   Tupla3f nor_ari;                         // valor auxiliar para ir calculando nor_arist_per
   Tupla3f nor_vert;                        // valor auxiliar para ir calculando nor_vert_per

   // Calculamos las normales de las aristas
   for(unsigned int i = 1; i < perfil.size(); ++i) {
      nor_ari = MAT_Rotacion(-90,{0.0,0.0,1.0})*(perfil[i] - perfil[i-1]);
      if(nor_ari.lengthSq() != 0.0)
         nor_ari = nor_ari.normalized();
      nor_arist_per.push_back(nor_ari);
   }

   // Calculamos las normales de los vertices
   nor_vert_per.push_back(nor_arist_per[0]);
   for(unsigned int i = 0; i < nor_arist_per.size() - 1; ++i){
      nor_vert = (nor_arist_per[i] + nor_arist_per[i+1]).normalized();
      nor_vert_per.push_back(nor_vert);
   }
   nor_vert_per.push_back(nor_arist_per[nor_arist_per.size()-1]);

   // Calculamos las coordenadas de textura
   vector<float> d;
   vector<float> t;

   // Cálculo de d
   for(unsigned int i = 0; i < perfil.size() - 1; ++i)
      d.push_back(sqrt((perfil[i+1] - perfil[i]).lengthSq()));

   // Calculamos el normalizador
   float sum = 0.0f;
   for(uint i = 0; i < d.size(); ++i)
      sum += d[i];

   // Inicializamos t para simplificar el algoritmo
   for(unsigned int i = 0; i < perfil.size(); ++i)
      t.push_back(0.0);

   // Cálculo de t
   for(unsigned int i = 0; i < perfil.size(); ++i) {
      for(unsigned int j = 0; j < i; ++j)
         t[i] += d[j];

      t[i] = t[i]/sum*1.0f;
   }

   // COMPLETAR: Práctica 2: completar: creación de la malla....

   vertices.clear();

   // Tabla de vértices y de normales de vértices + Coordenadas de textura
   for(unsigned int i = 0; i <= num_copias-1; ++i) {
      float angulo_rot = 2*180*i/(num_copias-1);
      for(unsigned int j = 0; j <= perfil.size()-1; ++j) {
         Matriz4f matriz_rot = MAT_Rotacion(angulo_rot, Tupla3f({0,+1.0,0})); // Rotación respecto al eje Y

         Tupla3f q = matriz_rot * perfil[j];
         vertices.push_back(q);
         
         Tupla3f r = matriz_rot * nor_vert_per[j];
         nor_ver.push_back(r);

         cc_tt_ver.push_back({i/(num_copias-1.0f),1-t[j]});
      }
   }

   // Tabla de triángulos
   for(unsigned int i = 0; i <= num_copias-2; ++i)
      for(unsigned int j = 0; j <= perfil.size()-2; ++j) {
         unsigned int k = i * perfil.size() + j;
         triangulos.push_back(Tupla3u({k, k+perfil.size(), k+perfil.size()+1}));
         triangulos.push_back(Tupla3u({k, k+perfil.size()+1, k+1}));
      }
}

// -----------------------------------------------------------------------------
// constructor, a partir de un archivo PLY

MallaRevolPLY::MallaRevolPLY
(
   const std::string & nombre_arch,
   const unsigned      nperfiles
)
{
   ponerNombre( std::string("malla por revolución del perfil en '"+ nombre_arch + "'" ));
   // COMPLETAR: práctica 2: crear la malla de revolución
   // Leer los vértice del perfil desde un PLY, después llamar a 'inicializar'
   // ...........................
   std::vector<Tupla3f> perfil;
   LeerVerticesPLY(nombre_arch, perfil);
   inicializar(perfil, nperfiles);
   CError();
}

// ****************************************************************************
// Clase 'Cilindro
Cilindro::Cilindro
(
   const int num_verts_per, // número de vértices del perfil original
   const unsigned nperfiles // número de perfiles
) 
{
   ponerNombre( std::string("malla por revolución del perfil de un Cilindro") );

   vector<Tupla3f> perfil;

   double distancia_ptos = 1.0/num_verts_per;

   perfil.push_back(Tupla3f{+1.0,0,0});

   for(unsigned int i = 1; i <= num_verts_per; ++i)
      perfil.push_back( {+1.0, perfil[i-1][Y]+distancia_ptos, 0} );

   inicializar(perfil, nperfiles);
}

// ****************************************************************************
// Clase 'Cono
Cono::Cono
(
   const int num_verts_per, // número de vértices del perfil original
   const unsigned nperfiles // número de perfiles
) 
{
   ponerNombre( std::string("malla por revolución del perfil de un Cono") );

   vector<Tupla3f> perfil;

   double distancia_ptos = 1.0/num_verts_per;

   perfil.push_back(Tupla3f{0,+1.0,0});

   for(unsigned int i = 1; i <= num_verts_per; ++i)
      perfil.push_back( {perfil[i-1][X]+distancia_ptos, perfil[i-1][Y]-distancia_ptos, 0} );

   inicializar(perfil, nperfiles);
}

// ****************************************************************************
// Clase 'Esfera
Esfera::Esfera
(
   const int num_verts_per, // número de vértices del perfil original
   const unsigned nperfiles // número de perfiles
) 
{
   ponerNombre( std::string("malla por revolución del perfil de una Esfera") );

   vector<Tupla3f> perfil;

   float distancia_ptos = M_PI/num_verts_per;

   for(unsigned int i = 0; i <= num_verts_per; ++i)
      perfil.push_back( {cos(float(-M_PI/2) + i*distancia_ptos), sin(float(-M_PI/2) + i*distancia_ptos), 0} );       // Ecuaciones paramétricas de una circunferencia
   
   inicializar(perfil, nperfiles);
}

// ****************************************************************************
// Clase 'Toro
Toro::Toro
(
   const int num_verts_per, // número de vértices del perfil original
   const unsigned nperfiles, // número de perfiles
   const double x,           // Coordenada x del centro de la circunferencia que genera el toro
   const double y,           // Coordenada y del centro de la circunferencia que genera el toro
   const double r            // Radio menor
) 
{
   ponerNombre( std::string("malla por revolución del perfil de un Toro") );

   vector<Tupla3f> perfil;

   float distancia_ptos = 2*M_PI/num_verts_per;

   for(unsigned int i = 0; i <= num_verts_per; ++i)
      perfil.push_back( {r*cos(float(-M_PI/2) + i*distancia_ptos)+x, r*sin(float(-M_PI/2) + i*distancia_ptos)+y, 0} );      // Ecuaciones paramétricas de una circunferencia

   inicializar(perfil, nperfiles);
}

// ****************************************************************************
// EXAMEN 21/11/2022. Ejercicio P2

void MallaBarrido::inicializar
(
   const std::vector<Tupla3f> & perfil,     // tabla de vértices del perfil original
   const unsigned               num_copias  // número de copias del perfil
)
{

   // Tabla de vértices
   for(unsigned int i = 0; i <= num_copias-1; ++i) {
      for(unsigned int j = 0; j <= perfil.size()-1; ++j) {
         Matriz4f matriz_tras = MAT_Traslacion({0, float(i)/5.0, 0}); // Traslación en el eje Y
         Tupla3f q = matriz_tras * perfil[j];
         vertices.push_back(q);
      }
   }

   // Tabla de triángulos
   for(unsigned int i = 0; i <= num_copias-2; ++i)
      for(unsigned int j = 0; j <= perfil.size()-2; ++j) {
         unsigned int k = i * perfil.size() + j;
         triangulos.push_back(Tupla3u({k, k+perfil.size(), k+perfil.size()+1}));
         triangulos.push_back(Tupla3u({k, k+perfil.size()+1, k+1}));
      }
}

// ****************************************************************************
// EXAMEN 21/11/2022. Ejercicio P2
SemiCilindroBarrido::SemiCilindroBarrido
(
   const int m, // número de vértices del perfil original
   const unsigned n // número de perfiles
) 
{
   ponerNombre( std::string("malla por traslación del perfil de un semicilindro") );

   vector<Tupla3f> perfil;

   double distancia_ptos = 1.0/m;

   perfil.push_back(Tupla3f{+1.0,0,0});

   for(unsigned int i = 1; i < m; ++i)
      perfil.push_back( {float(cos(i*M_PI/(m-1))), 0, float(sin(i*M_PI/(m-1)))} );

   inicializar(perfil, n);
}